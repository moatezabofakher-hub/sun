@echo off
chcp 65001 >NUL
title Tiqany Acc Manager - Build for Windows
cd /d "%~dp0"
echo Tiqany Acc Manager - Windows installer builder
echo.
where node >NUL 2>NUL
if errorlevel 1 (
 echo Node.js 22+ not found. Install it from https://nodejs.org/
 pause
 exit /b 1
)
echo Installing project dependencies ...
call npm install --no-audit --no-fund
if errorlevel 1 goto failed
echo Checking accounting, networking and peripherals ...
call npm test
if errorlevel 1 goto failed
echo Building Windows EXE installer ...
call npm run build:win
if errorlevel 1 goto failed
echo.
echo SUCCESS: Find the Windows installer in the dist folder.
pause
exit /b 0
:failed
echo.
echo ERROR: Build failed. Review the messages above.
pause
exit /b 1
