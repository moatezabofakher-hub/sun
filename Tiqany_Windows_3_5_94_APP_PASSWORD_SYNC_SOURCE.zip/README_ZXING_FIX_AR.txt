Fix: @zxing/library 0.21.3 for @zxing/browser 0.1.5; GitHub npm ERESOLVE dependency error.
