'use strict';
/** Separate encrypted TCP listener for main-phone <-> Windows ledger reconciliation.
 * The established agent protocol and its credentials are not reused.
 */
const net = require('node:net');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const PORT = 39271;
const MAX_FRAME = 12_000_000;
function encode(key, payload) {
  const nonce=crypto.randomBytes(12);
  const cipher=crypto.createCipheriv('aes-256-gcm',key,nonce);
  const encrypted=Buffer.concat([cipher.update(JSON.stringify(payload),'utf8'),cipher.final()]);
  const tag=cipher.getAuthTag();
  const b=Buffer.from(JSON.stringify({iv:nonce.toString('base64'),data:Buffer.concat([encrypted,tag]).toString('base64')}));
  if(b.length>MAX_FRAME) throw Error('sync packet too large');
  const frame=Buffer.alloc(4+b.length);frame.writeUInt32BE(b.length);b.copy(frame,4);return frame;
}
function decode(key, input) {
  const msg=JSON.parse(Buffer.from(input).toString('utf8'));
  if(!msg||typeof msg.iv!=='string'||typeof msg.data!=='string')throw Error('malformed packet');
  const iv=Buffer.from(msg.iv,'base64'),bytes=Buffer.from(msg.data,'base64');
  if(iv.length!==12||bytes.length<16||bytes.length>MAX_FRAME)throw Error('invalid packet');
  const decipher=crypto.createDecipheriv('aes-256-gcm',key,iv);
  decipher.setAuthTag(bytes.subarray(bytes.length-16));
  return JSON.parse(Buffer.concat([decipher.update(bytes.subarray(0,-16)),decipher.final()]).toString('utf8'));
}
function ipv4(){return [...new Set(Object.values(os.networkInterfaces()).flat().filter(x=>x?.family==='IPv4'&&!x.internal&&/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/.test(x.address)).map(x=>x.address))];}
class PeerLanServer {
  constructor({userData,onRequest=()=>{},onStatus=()=>{},BonjourClass=null}={}){
    this.configPath=path.join(userData,'main-phone-peer.json');this.onRequest=onRequest;this.onStatus=onStatus;
    this.pending=new Map();this.sockets=new Set();this.ready=false;this.server=null;
    this.BonjourClass=BonjourClass;this.bonjour=null;this.advertisement=null;this.advertisedIPs='';this.networkTimer=null;
    try { const saved=JSON.parse(fs.readFileSync(this.configPath,'utf8'));
      if(!/^[a-f0-9]{32}$/.test(saved.id)||! /^[A-Za-z0-9_-]{43}$/.test(saved.key))throw Error('bad key');
      this.id=saved.id;this.key=Buffer.from(saved.key,'base64url');
      if(this.key.length!==32)throw Error('bad key');
    } catch (_){this.id=crypto.randomBytes(16).toString('hex');this.key=crypto.randomBytes(32);
      fs.mkdirSync(userData,{recursive:true});fs.writeFileSync(this.configPath,JSON.stringify({id:this.id,key:this.key.toString('base64url')}),{mode:0o600});}
  }
  config(){return {serverId:this.id,key:this.key.toString('base64url'),port:PORT,ips:ipv4(),ready:this.ready};}
  start(){if(this.server)return;
    this.server=net.createServer(socket=>this.handle(socket));
    this.server.on('error',e=>{this.ready=false;this.onStatus('تعذر فتح منفذ المزامنة: '+e.message);});
    this.server.listen(PORT,'0.0.0.0',()=>{this.ready=true;this.advertise();this.onStatus('ready');});
  }
  advertise(){
    if(!this.ready)return;
    try{
      if(!this.bonjour){const Bonjour=this.BonjourClass||require('bonjour-service').Bonjour;this.bonjour=new Bonjour();}
      this.advertisement?.stop();
      this.advertisement=this.bonjour.publish({name:'TA-MAIN-'+this.id.slice(0,16),type:'tiqanymain',protocol:'tcp',port:PORT});
      this.advertisedIPs=ipv4().sort().join(',');
      if(!this.networkTimer){
        this.networkTimer=setInterval(()=>{
          const addresses=ipv4().sort().join(',');
          if(this.ready&&addresses!==this.advertisedIPs)this.advertise();
        },12000);this.networkTimer.unref?.();
      }
    }catch(err){this.onStatus('تعذّر الإعلان التلقائي للكمبيوتر: '+err.message);}
  }
  handle(socket){
    this.sockets.add(socket); socket.setTimeout(25000);
    let buffer=Buffer.alloc(0),size=-1,received=false;
    const cleanup=()=>{this.sockets.delete(socket);if(socket.requestId){const p=this.pending.get(socket.requestId);if(p){clearTimeout(p.timeout);this.pending.delete(socket.requestId);}}};
    socket.on('close',cleanup);socket.on('error',()=>socket.destroy());socket.on('timeout',()=>socket.destroy());
    socket.on('data',chunk=>{
      if(received)return socket.destroy();
      buffer=Buffer.concat([buffer,chunk]);
      if(size<0&&buffer.length>=4){size=buffer.readUInt32BE(0);if(!size||size>MAX_FRAME)return socket.destroy();}
      if(size>=0&&buffer.length>size+4)return socket.destroy();
      if(size>=0&&buffer.length===size+4){received=true;
        try {const data=decode(this.key,buffer.subarray(4));
          if(!data||data.protocol!=='TIQANY-PEER-1'||!['fetch','commit','report-conflicts'].includes(data.action))throw Error('unsupported protocol');
          const requestId=crypto.randomUUID();socket.requestId=requestId;
          const timeout=setTimeout(()=>this.reply(requestId,{ok:false,error:'انتهت مهلة استجابة الكمبيوتر'}),20000);
          this.pending.set(requestId,{socket,timeout});this.onRequest({requestId,data});
        }catch(_){socket.destroy();}
      }
    });
  }
  reply(id,response){const p=this.pending.get(id);if(!p)return false;
    this.pending.delete(id);clearTimeout(p.timeout);p.socket.requestId=null;
    try{p.socket.end(encode(this.key,response));return true;}catch(_){p.socket.destroy();return false;}
  }
  stop(){this.ready=false;if(this.networkTimer)clearInterval(this.networkTimer);this.networkTimer=null;
    try{this.advertisement?.stop();}catch(_){}this.advertisement=null;
    try{this.bonjour?.destroy();}catch(_){}this.bonjour=null;for(const p of this.pending.values())clearTimeout(p.timeout);this.pending.clear();for(const sock of this.sockets)sock.destroy();this.sockets.clear();this.server?.close();this.server=null;}
}
module.exports={PeerLanServer,encode,decode,PORT,MAX_FRAME};
