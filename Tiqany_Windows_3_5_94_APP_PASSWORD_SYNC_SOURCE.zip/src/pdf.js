'use strict';
function esc(x) {return String(x == null ? '' : x).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function n(x,decimals=2) {return Number.isFinite(Number(x)) ? new Intl.NumberFormat('en-US',{minimumFractionDigits:0,maximumFractionDigits:Math.min(4,Math.max(0,Number(decimals)||0))}).format(Number(x)) : '0';}
function displayCurrency(c) {return c === 'SYP' ? 'ل.س' : c;}
function monetary(x,c) {return `${n(x,2)} ${esc(displayCurrency(c))}`;}
const style = `
@page{size:A4;margin:14mm 14mm 16mm}
*{box-sizing:border-box}body{direction:rtl;font-family:'Tahoma','Segoe UI','Arial',sans-serif;font-size:12px;color:#123043;line-height:1.85;margin:0}
h1,h2{margin:0;color:#0d5963}h1{font-size:22px}h2{font-size:17px;margin-top:5px}.head{text-align:center;border-bottom:3px solid #119387;padding:8px 0 15px}
.sub{text-align:center;color:#627788}.topline{display:flex;justify-content:space-between;gap:20px;margin:14px 0}.meta{margin:12px 0;padding:9px 12px;background:#f1f8fa;border:1px solid #d5e9ee;border-radius:8px}
table{width:100%;border-collapse:collapse;table-layout:auto;margin:13px 0;font-size:11px}thead{display:table-header-group}tr{page-break-inside:avoid}
th{background:#126c75;color:white}th,td{padding:7px 8px;border:1px solid #d6e4e9;text-align:right;vertical-align:top}tbody tr:nth-child(even){background:#f6fafb}
.num{text-align:left;direction:ltr;white-space:nowrap}.total{display:flex;justify-content:space-between;border-bottom:1px solid #d7e4e9;padding:5px 8px}.total.strong{font-size:14px;font-weight:bold;color:#0b7468;background:#effaf5}
.footer{border-top:1px solid #cbdce2;margin-top:18px;padding-top:7px;text-align:center;color:#728394;font-size:10px}
.logo{max-height:86px;max-width:130px;object-fit:contain;margin:0 auto 8px;display:block}`;
function doc(body,title) {return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${esc(title)}</title><style>${style}</style></head><body>${body}</body></html>`;}
function logoData(str) {return typeof str==='string' && /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(str) && str.length < 2400000 ? `<img class="logo" alt="" src="${str}">` : '';}
function reportHTML(r) {
  if(!r || !Array.isArray(r.rows) || r.rows.length>8000) throw Error('Invalid report');
  const rows=r.rows.map((x,i)=>`<tr><td class="num">${i+1}</td><td>${esc(x.name)}</td><td>${esc(x.detail)}</td></tr>`).join('');
  const totals=r.totals||{};
  return doc(`<div class="head"><h1>${esc(r.companyName||'المحاسب التقني')}</h1><div class="sub">${esc(r.companyPhone)} ${esc(r.companyAddress)}</div><h2>${esc(r.title||'تقرير محاسبي')}</h2><div class="sub">${esc(r.range)}</div></div>
  <table><thead><tr><th>م</th><th>البيان</th><th>التفاصيل</th></tr></thead><tbody>${rows}</tbody></table>
  <div class="total strong">الإجمالي بالدولار <span>${monetary(totals.USD||0,'USD')}</span></div>
  <div class="total strong">الإجمالي بالليرة <span>${monetary(totals.SYP||0,'SYP')}</span></div>
  <div class="footer">عدد البنود: ${r.rows.length} — هذا التقرير مستخرج من السجلات المحاسبية المحفوظة.</div>`,r.title||'تقرير');
}
function invoiceHTML(r) {
  if(!r || !Array.isArray(r.rows) || r.rows.length>2500)throw Error('Invalid invoice');
  const currency=r.currency==='SYP'?'SYP':'USD';
  const decimals=Math.min(4,Math.max(0,Number(r.priceDecimals)||2));
  const rows=r.rows.map((x,i)=>`<tr><td class="num">${i+1}</td><td>${esc(x.itemName)}</td><td>${esc(x.unitName)}</td><td class="num">${n(x.qty,decimals)}</td><td class="num">${n(x.price,decimals)}</td><td class="num">${n(x.total,2)}</td></tr>`).join('');
  const totals = [['المجموع',r.subTotal],['الحسم',r.discountAmount],['الضريبة والإضافات',r.taxAmount],['صافي الفاتورة',r.netTotal],['المدفوع',r.paidAmount],['المتبقي',r.remainingAmount]];
  const b=r.previousBalances?.[currency] ?? r.previousBalance;
  const a=r.finalBalances?.[currency] ?? r.finalBalance;
  return doc(`<div class="head">${logoData(r.companyLogo)}<h1>${esc(r.companyName||'المحاسب التقني')}</h1><div class="sub">${esc(r.companyPhone)} ${esc(r.companyAddress)}</div><h2>${esc(r.title||'فاتورة')}</h2></div>
  <div class="meta"><div>رقم الفاتورة: <b>${esc(r.number)}</b> — التاريخ: ${esc(r.date)}</div><div>الحساب: <b>${esc(r.accountName)}</b></div>${r.accountPhone?`<div>هاتف العميل: ${esc(r.accountPhone)}</div>`:''}${r.accountAddress?`<div>العنوان: ${esc(r.accountAddress)}</div>`:''}</div>
  <table><thead><tr><th>#</th><th>المادة</th><th>الوحدة</th><th>الكمية</th><th>السعر (${displayCurrency(currency)})</th><th>الإجمالي (${displayCurrency(currency)})</th></tr></thead><tbody>${rows}</tbody></table>
  ${totals.filter(([label,val])=>label!=='الحسم'&&label!=='الضريبة والإضافات'||Number(val)!==0).map(([label,val])=>`<div class="total ${label==='صافي الفاتورة'?'strong':''}">${label}<span>${monetary(val,currency)}</span></div>`).join('')}
  ${b!==undefined&&b!==null?`<div class="total">الرصيد قبل الفاتورة (${displayCurrency(currency)}) <span>${monetary(b,currency)}</span></div>`:''}
  ${a!==undefined&&a!==null?`<div class="total strong">الرصيد النهائي (${displayCurrency(currency)}) <span>${monetary(a,currency)}</span></div>`:''}
  ${r.note?`<div class="meta">ملاحظات: ${esc(r.note)}</div>`:''}
  <div class="footer">تم إنشاء هذه الفاتورة بواسطة المحاسب التقني.</div>`,r.title||'فاتورة');
}

function statementHTML(r) {
 if(!r || !Array.isArray(r.rows) || r.rows.length>8000) throw Error('Invalid account statement');
 const balance=(b,c)=>`${esc(String(b?.[c]??'0'))} ${c==='SYP'?'ل.س':'USD'}`;
 const head=`<div class="head">${logoData(r.companyLogo)}<h1>${esc(r.companyName||'المحاسب التقني')}</h1><div class="sub">${esc(r.companyPhone)} | ${esc(r.companyAddress)} ${r.companyEmail?' | '+esc(r.companyEmail):''}</div><h2>كشف حساب تفصيلي</h2><div class="sub">${esc(r.range)}</div></div>
 <div class="meta"><strong>الحساب: ${esc(r.accountName)}</strong><div>${esc(r.accountPhone)} ${esc(r.accountAddress)}</div></div>`;
 const result=`<div class="totline"><div>الرصيد المدور: <strong>${balance(r.opening,'USD')}</strong> | <strong>${balance(r.opening,'SYP')}</strong></div>
 <div>الرصيد النهائي: <strong>${balance(r.ending,'USD')}</strong> | <strong>${balance(r.ending,'SYP')}</strong></div></div>`;
 const rows=r.rows.map(e=>`<tr><td>${esc(e.date)}</td><td>${esc(e.reference)}<small>${esc(e.detail)}</small></td><td>${esc(e.currency)}</td><td class="num">${esc(e.rate||'—')}</td><td class="pos num">${e.debit!=='0'?esc(e.debit):'—'}</td><td class="neg num">${e.credit!=='0'?esc(e.credit):'—'}</td><td class="num">${esc(e.balance)}</td></tr>`).join('');
 const body=`${head}${result}<table><thead><tr><th>التاريخ</th><th>الحركة والتفاصيل</th><th>العملة</th><th>سعر الصرف</th><th>زيادة (+)</th><th>نقصان (−)</th><th>الرصيد</th></tr></thead><tbody>${rows||'<tr><td colspan="7">لا توجد حركات خلال الفترة المختارة</td></tr>'}</tbody></table>
 ${result}<div class="footer">تاريخ الإصدار: ${esc(r.createdAt)} — إجمالي الحركات: ${r.rows.length} ${r.footerNote?'- '+esc(r.footerNote):''}</div>`;
 return doc(body,r.title||'كشف حساب تفصيلي').replace('</style>',`\n.pos{background:#e8f8ed;color:#075d2f;font-weight:bold}.neg{background:#feeaeb;color:#9b1831;font-weight:bold}small{display:block;color:#52606c;font-size:9px;white-space:normal}.totline{border:1px solid #bdd5eb;background:#eef7ff;border-radius:9px;padding:10px;margin:10px 0;font-size:13px;line-height:2.2;page-break-inside:avoid}.totline strong{color:#104373}table{font-size:9px;table-layout:fixed}th,td{padding:6px 4px;overflow-wrap:anywhere}\n</style>`);
}

module.exports = { esc, reportHTML, invoiceHTML, statementHTML };
