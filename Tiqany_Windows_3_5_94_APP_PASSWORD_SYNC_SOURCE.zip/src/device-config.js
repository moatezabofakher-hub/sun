'use strict';
const fs = require('node:fs');
const path = require('node:path');

const DEFAULTS = Object.freeze({
  printerName: '',
  printMode: 'thermal', // thermal = Windows spooler RAW ESC/POS; system = regular Windows print dialog
  paperMm: 80,
  scanner: { autoCapture: true, minLength: 4, maxGapMs: 110, suffix: 'both' }
});
const cleanName = value => String(value ?? '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 255);
const clamp = (value, defaultValue, min, max) => {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : defaultValue;
};
function normalizeDeviceConfig(raw = {}) {
  const data = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const scanner = data.scanner && typeof data.scanner === 'object' ? data.scanner : {};
  return {
    printerName: cleanName(data.printerName),
    printMode: data.printMode === 'system' ? 'system' : 'thermal',
    paperMm: data.paperMm === 58 || Number(data.paperMm) === 58 ? 58 : 80,
    scanner: {
      autoCapture: scanner.autoCapture !== false,
      minLength: clamp(scanner.minLength, 4, 3, 32),
      maxGapMs: clamp(scanner.maxGapMs, 110, 30, 500),
      suffix: ['enter', 'tab', 'both'].includes(scanner.suffix) ? scanner.suffix : 'both'
    }
  };
}
function loadDeviceConfig(filepath) {
  try { return normalizeDeviceConfig(JSON.parse(fs.readFileSync(filepath, 'utf8'))); }
  catch (_) { return normalizeDeviceConfig(DEFAULTS); }
}
function writeDeviceConfig(filepath, config) {
  const normalized = normalizeDeviceConfig(config);
  fs.mkdirSync(path.dirname(filepath), {recursive: true});
  const temp = filepath + '.new';
  fs.writeFileSync(temp, JSON.stringify(normalized, null, 2), {encoding:'utf8', mode:0o600});
  fs.renameSync(temp, filepath);
  return normalized;
}
function makeThermalTestBytes(widthMm) {
  const width = widthMm === 58 ? '58' : '80';
  return Buffer.concat([
    Buffer.from([0x1b,0x40,0x1b,0x61,0x01,0x1b,0x45,0x01]),
    Buffer.from('TIQANY ACC\nUSB PRINTER TEST\nPAPER: '+width+' mm\n', 'ascii'),
    Buffer.from([0x1b,0x45,0x00,0x1b,0x61,0x00]),
    Buffer.from('-----------------------------\n', 'ascii'),
    Buffer.from('If this prints, RAW ESC/POS works.\n\n\n', 'ascii'),
    Buffer.from([0x1d,0x56,0x42,0x00])
  ]);
}
module.exports = {DEFAULTS, normalizeDeviceConfig, loadDeviceConfig, writeDeviceConfig, makeThermalTestBytes};
