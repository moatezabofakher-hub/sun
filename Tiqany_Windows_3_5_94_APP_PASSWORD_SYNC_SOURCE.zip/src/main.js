'use strict';
const { app, BrowserWindow, ipcMain, protocol, net: electronNet, dialog, shell, Menu } = require('electron');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { spawn } = require('node:child_process');
const { ManagerLanServer } = require('./lan-server');
const { PeerLanServer } = require('./peer-lan-server');
const { BackupService, safeFilename } = require('./backup');
const { reportHTML, invoiceHTML, statementHTML } = require('./pdf');
const { normalizeDeviceConfig, loadDeviceConfig, writeDeviceConfig, makeThermalTestBytes } = require('./device-config');

protocol.registerSchemesAsPrivileged([{
  scheme: 'tiqany', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true }
}]);
const persistentUserData = path.join(app.getPath('appData'), 'TiqanyAccManager');
fs.mkdirSync(persistentUserData, { recursive: true });
app.setPath('userData', persistentUserData);
const single = app.requestSingleInstanceLock();
if (!single) app.quit();

const webRoot = path.resolve(__dirname, '../web');
let mainWindow, lan, backup, peerLan;
let exitConfirmed = false;
let printerName = '';
let deviceConfig = normalizeDeviceConfig();
let configPath;
const maxJSON = 6_000_000;
const isTrusted = event => mainWindow && !mainWindow.isDestroyed() && event.sender.id === mainWindow.webContents.id;
const emit = (name, payload) => { if (mainWindow && !mainWindow.isDestroyed() && !mainWindow.webContents.isLoading()) mainWindow.webContents.send(name, payload); };
const notice = (message, kind='info') => dialog.showMessageBox(mainWindow, { type: kind, title: 'Tiqany Acc Manager', message, buttons: ['حسناً'] });

async function generatePDF(kind, raw, suggestedName) {
  if (raw.length > maxJSON) throw Error('حجم التقرير كبير جداً');
  const value = JSON.parse(raw);
  const html = kind === 'invoice' ? invoiceHTML(value) : kind === 'report' ? (value.reportType === 'account_statement' ? statementHTML(value) : reportHTML(value)) : null;
  if (!html) throw Error('نوع PDF غير معروف');
  const { canceled, filePath } = await dialog.showSaveDialog(mainWindow, {
    title: 'حفظ PDF على ويندوز', defaultPath: safeFilename(suggestedName,'Tiqany-Report.pdf').replace(/\.(?!pdf$)[^.]+$/i,'') ,
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (canceled || !filePath) return;
  const preview = new BrowserWindow({show:false, webPreferences: { sandbox:true, nodeIntegration:false, contextIsolation:true }});
  try {
    await preview.loadURL('data:text/html;charset=utf-8;base64,'+Buffer.from(html,'utf8').toString('base64'));
    await preview.webContents.executeJavaScript('document.fonts.ready.then(() => true)');
    const bytes = await preview.webContents.printToPDF({printBackground:true, preferCSSPageSize:true});
    await fs.promises.writeFile(filePath, bytes, {flag:'w'});
    await notice('تم حفظ PDF بنجاح:\n' + filePath);
  } finally {preview.destroy();}
}

function readConfig() {
  deviceConfig = loadDeviceConfig(configPath);
  printerName = deviceConfig.printerName;
}
function persistConfig(config = deviceConfig) {
  deviceConfig = writeDeviceConfig(configPath, config);
  printerName = deviceConfig.printerName;
  emit('ta-device-config', deviceConfig);
  return deviceConfig;
}
async function systemPrinters() {
  if (!mainWindow || mainWindow.isDestroyed()) return [];
  return (await mainWindow.webContents.getPrintersAsync()).map(p => ({
    name: String(p.name || ''), displayName: String(p.displayName || p.name || ''),
    isDefault: !!p.isDefault, status: Number(p.status || 0)
  }));
}
async function choosePrinter() {
  if (process.platform !== 'win32') {
    emit('ta-printer-status', {state:'error', message:'اختيار طابعة ويندوز يتطلب ويندوز'}); return;
  }
  const printers = await systemPrinters();
  if (!printers.length) {
    emit('ta-printer-status', {state:'error',message:'لا توجد طابعة مثبتة في إعدادات Windows. ثبّت تعريف USB ثم اضغط تحديث.'}); return;
  }
  const names = printers.map(p => p.name).slice(0,20);
  const result = await dialog.showMessageBox(mainWindow, {
    type:'question', title:'طابعات USB والشبكة', message:'اختر طابعة مثبتة في Windows',
    detail:'للطابعة الحرارية ESC/POS اختر النوع حرارية من لوحة الأجهزة، ولـ A4 اختر طباعة عادية.',
    buttons:[...names,'إلغاء'], cancelId:names.length, defaultId:0, noLink:true
  });
  if (result.response >= names.length) return;
  persistConfig({...deviceConfig, printerName:names[result.response]});
  emit('ta-printer-status', {state:'connected', address:printerName, message:printerName});
}
async function printWindowsPage(silent=false) {
  if (process.platform !== 'win32') throw Error('الطباعة تتطلب نظام Windows');
  if (silent && !printerName) throw Error('حدد الطابعة في لوحة الأجهزة أولاً');
  if (silent && !(await systemPrinters()).some(p=>p.name===printerName)) throw Error('الطابعة المختارة غير مثبتة في Windows');
  return new Promise((resolve,reject) => {
    mainWindow.webContents.print({silent, ...(silent?{deviceName:printerName}:{}), printBackground:true},
      (success, reason) => success ? resolve({ok:true}) : reject(Error(reason || 'تعذرت الطباعة؛ افحص حالة الطابعة')));
  });
}
async function printA4Invoice(input) {
  if (process.platform !== 'win32') throw Error('الطباعة المباشرة متاحة على Windows فقط');
  if (!printerName || deviceConfig.printMode !== 'system')
    throw Error('اختر طابعة عادية A4 من إعدادات الأجهزة أولاً');
  if (!(await systemPrinters()).some(p=>p.name===printerName))
    throw Error('الطابعة المختارة غير موجودة ضمن طابعات Windows');
  if (!input || typeof input !== 'object' || Buffer.byteLength(JSON.stringify(input),'utf8') > maxJSON)
    throw Error('محتوى الفاتورة غير صالح أو كبير جداً');
  const html = invoiceHTML(input);
  const windowForPrint = new BrowserWindow({show:false,webPreferences:{sandbox:true,nodeIntegration:false,contextIsolation:true}});
  try {
    await windowForPrint.loadURL('data:text/html;charset=utf-8;base64,'+Buffer.from(html,'utf8').toString('base64'));
    await windowForPrint.webContents.executeJavaScript('document.fonts.ready.then(() => true)');
    await new Promise((resolve,reject)=>windowForPrint.webContents.print({
      silent:true,deviceName:printerName,printBackground:true,pageSize:'A4',margins:{marginType:'default'}
    },(success,reason)=>success?resolve():reject(Error(reason||'رفض Windows أمر طباعة الفاتورة'))));
    return {ok:true,message:'أُرسلت الفاتورة إلى قائمة طباعة '+printerName};
  } finally {if(!windowForPrint.isDestroyed())windowForPrint.destroy();}
}
async function testDevicePrinter() {
  if (!printerName) throw Error('اختر طابعة USB أو طابعة عادية مثبتة في Windows أولاً');
  if (!(await systemPrinters()).some(p=>p.name===printerName)) throw Error('طابعة Windows المحددة غير موجودة؛ أعد تحديث القائمة');
  if (deviceConfig.printMode === 'thermal') {
    await printRaw(makeThermalTestBytes(deviceConfig.paperMm).toString('base64'));
    return {ok:true, message:'تم إرسال صفحة اختبار ESC/POS إلى قائمة الطباعة'};
  }
  const sample = `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>body{font-family:Arial,Tahoma,sans-serif;margin:18mm;color:#152d40}h1{color:#087c82;border-bottom:2px solid #087c82;padding-bottom:12px}p{font-size:14pt}small{color:#777}</style></head><body><h1>المحاسب التقني — اختبار الطابعة</h1><p>تم تجهيز صفحة اختبار عربية للطابعة العادية على Windows.</p><p>المقاس: A4 — التاريخ: ${new Date().toISOString().slice(0,10)}</p><small>Tiqany Acc Manager</small></body></html>`;
  const preview = new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
  try {
    await preview.loadURL('data:text/html;charset=utf-8;base64,'+Buffer.from(sample).toString('base64'));
    await new Promise((resolve,reject)=>preview.webContents.print({silent:true,deviceName:printerName,printBackground:true,pageSize:'A4'},
      (success, reason)=> success ? resolve() : reject(Error(reason || 'لم يتم قبول أمر طباعة A4'))));
    return {ok:true,message:'تم إرسال صفحة اختبار A4 إلى قائمة الطباعة'};
  } finally { if (!preview.isDestroyed()) preview.destroy(); }
}

async function printRaw(base64) {
  if (process.platform !== 'win32') throw Error('الطباعة المباشرة متاحة عند تشغيل البرنامج على ويندوز فقط');
  if (!printerName) throw Error('اختر الطابعة أولاً من إعدادات الطباعة');
  if (deviceConfig.printMode !== 'thermal') throw Error('تم اختيار طابعة A4. استخدم خيار طباعة الصفحة عبر Windows بدلاً من ESC/POS.');
  if (!(await systemPrinters()).some(p => p.name === printerName)) throw Error('الطابعة غير مثبتة في Windows. راجع اتصال USB والتعريف.');
  if(typeof base64!=='string'||base64.length>11_000_000||!/^[A-Za-z0-9+/=]+$/.test(base64)) throw Error('بيانات الطباعة غير صالحة');
  const bytes=Buffer.from(base64,'base64');
  if(!bytes.length||bytes.length>8_000_000)throw Error('حجم الطباعة غير صالح');
  emit('ta-printer-status',{state:'printing',message:'جارٍ إرسال الفاتورة إلى الطابعة'});
  const temp=await fs.promises.mkdtemp(path.join(os.tmpdir(),'tiqany-print-'));
  const input=path.join(temp,'receipt.bin');
  try {
    await fs.promises.writeFile(input,bytes,{mode:0o600});
    // PowerShell cannot read scripts directly inside Electron's virtual app.asar archive.
    // electron-builder's extraResources copies the script to a real file under resources/scripts.
    const rawPrintScript = app.isPackaged
      ? path.join(process.resourcesPath, 'scripts', 'print-raw.ps1')
      : path.resolve(__dirname, '../scripts/print-raw.ps1');
    if (!fs.existsSync(rawPrintScript)) {
      throw Error('ملف تشغيل الطابعة الحرارية غير موجود في تثبيت ويندوز. ثبّت النسخة المصححة من المحاسب التقني.');
    }
    await new Promise((resolve,reject)=>{
      const child=spawn('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
        '-File',rawPrintScript,'-PrinterName',printerName,'-InputFile',input],{windowsHide:true});
      let stderr='';
      child.stderr.on('data',chunk=>{stderr += chunk.toString().slice(0,400);});
      child.on('error',reject);
      child.on('close',code=>code===0?resolve():reject(Error(stderr||'فشل إرسال بيانات الطابعة')));
    });
    emit('ta-printer-status',{state:'printed',address:printerName,message:'تم إرسال الفاتورة إلى '+printerName});
  } finally {await fs.promises.rm(temp,{recursive:true,force:true});}
}

function handlers() {
  ipcMain.handle('ta-peer-config',e=>{if(!isTrusted(e))throw Error('غير مسموح');return peerLan?.config()||{};});
  ipcMain.on('ta-peer-reply',(e,requestId,data)=>{if(isTrusted(e)&&typeof data==='string'&&data.length<11_000_000){try{peerLan?.reply(requestId,JSON.parse(data));}catch(_){}}});
  ipcMain.handle('ta-devices-get',e=>{if(!isTrusted(e))throw Error('غير مسموح');return deviceConfig;});
  ipcMain.handle('ta-devices-printers',async e=>{if(!isTrusted(e))throw Error('غير مسموح');return systemPrinters();});
  ipcMain.handle('ta-devices-save',async(e,input)=>{
    if(!isTrusted(e))throw Error('غير مسموح');
    const next=normalizeDeviceConfig(input);
    if(next.printerName && !(await systemPrinters()).some(p=>p.name===next.printerName))
      throw Error('اختر طابعة موجودة ضمن الطابعات المثبتة في Windows');
    return persistConfig(next);
  });
  ipcMain.handle('ta-devices-test',async e=>{if(!isTrusted(e))throw Error('غير مسموح');return testDevicePrinter();});
  ipcMain.handle('ta-devices-print-page',async(e,silent)=>{if(!isTrusted(e))throw Error('غير مسموح');return printWindowsPage(!!silent);});
  ipcMain.handle('ta-devices-print-invoice',async(e,data)=>{if(!isTrusted(e))throw Error('غير مسموح');return printA4Invoice(data);});
  ipcMain.on('ta-lan-endpoint',e=>{
    if(!isTrusted(e)){e.returnValue='{}';return;}
    const addr=lan?.server?.address();
    const ips=Object.values(os.networkInterfaces()).flat().filter(x=>x?.family==='IPv4'&&!x.internal&&
      /^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/.test(x.address)).map(x=>x.address);
    e.returnValue=JSON.stringify({companyId:lan?.company||'',port:addr?.port||0,ips:[...new Set(ips)]});
  });
  ipcMain.on('ta-lan-start',(e,id)=>{e.returnValue=isTrusted(e)?lan.start(id):'invalid';});
  ipcMain.on('ta-lan-restart',(e,id)=>{e.returnValue=isTrusted(e)?lan.start(id,true):'invalid';});
  ipcMain.on('ta-lan-stop',e=>{if(isTrusted(e))lan.stop();});
  ipcMain.on('ta-lan-reply',(e,id,answer)=>{if(isTrusted(e) && typeof answer==='string' && answer.length<=7_800_000)lan.reply(id,answer);});
  ipcMain.on('ta-save-backup',async(e,raw,name)=>{
    if(!isTrusted(e)||typeof raw!=='string'||raw.length>160_000_000)return;
    try {
      const result=await dialog.showSaveDialog(mainWindow,{title:'حفظ نسخة احتياطية',
        defaultPath: safeFilename(name), filters:[{name:'JSON Backup',extensions:['json']}]});
      if(!result.canceled && result.filePath){await fs.promises.writeFile(result.filePath,raw,{encoding:'utf8'});await notice('تم حفظ النسخة الاحتياطية');}
    }catch(err){notice('تعذر حفظ النسخة: '+err.message,'error');}
  });
  ipcMain.on('ta-pdf',async(e,kind,raw,name)=>{if(!isTrusted(e))return;try{await generatePDF(kind,raw,name);}catch(err){await notice('تعذر إنشاء PDF: '+err.message,'error');}});
  ipcMain.on('ta-printer-choose',e=>{if(isTrusted(e))choosePrinter().catch(err=>emit('ta-printer-status',{state:'error',message:err.message}));});
  ipcMain.on('ta-printer-print',(e,data)=>{if(isTrusted(e))printRaw(data).catch(err=>emit('ta-printer-status',{state:'error',message:err.message}));});
  ipcMain.on('ta-backup-status-get',e=>{e.returnValue=isTrusted(e)?JSON.stringify(backup.status()):'{}';});
  ipcMain.on('ta-backup-stage',(e,raw)=>{if(isTrusted(e))backup.stageSnapshot(raw);});
  ipcMain.on('ta-backup-configure',(e,kind,enabled,hours)=>{e.returnValue=isTrusted(e)?backup.configure(kind,enabled,hours):'غير مسموح';});
  ipcMain.on('ta-backup-folder',async e=>{
    if(!isTrusted(e))return;
    try {
      const result=await dialog.showOpenDialog(mainWindow,{title:'مجلد النسخ الاحتياطي',properties:['openDirectory','createDirectory']});
      if (!result.canceled && result.filePaths[0])backup.setFolder(result.filePaths[0]);
    }catch(err){await notice('تعذر تحديد المجلد: '+err.message,'error');}
  });
  ipcMain.on('ta-backup-drive',e=>{if(isTrusted(e))notice('Google Drive ليس مفعّلاً في نسخة ويندوز الحالية. استخدم النسخ الاحتياطي المحلي.', 'warning');});
  ipcMain.on('ta-backup-now',e=>{if(isTrusted(e))backup.runNow('local').then(ok=>notice(ok?'تم حفظ النسخة الاحتياطية المحلية':'تعذر حفظ النسخة؛ راجع الضبط','info'));});
  ipcMain.on('ta-exit',e=>{if(isTrusted(e)){exitConfirmed=true;app.quit();}});
}

async function createWindow() {
  mainWindow=new BrowserWindow({
    title:'المحاسب التقني — إدارة موظفي البيع', width:1360,height:900,minWidth:820,minHeight:600,
    backgroundColor:'#eef5f7',show:false,fullscreen:false,autoHideMenuBar:false,
    icon:path.join(__dirname,'../assets/icon.png'),
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true,
      devTools:!app.isPackaged, webSecurity:true, spellcheck:false}
  });
  // Show maximized to the OS work area, leaving the Windows taskbar visible.
  mainWindow.once('ready-to-show',()=>{mainWindow.show();mainWindow.maximize();});
  mainWindow.webContents.setWindowOpenHandler(({url})=>{
    if (/^https:\/\//i.test(url)) shell.openExternal(url).catch(()=>{});
    return {action:'deny'};
  });
  mainWindow.webContents.on('will-navigate',(event,url)=>{
    if (!url.startsWith('tiqany://app/')) event.preventDefault();
  });
  mainWindow.webContents.session.setPermissionRequestHandler((_wc,permission,callback)=>callback(permission==='media'));
  // Window X / Alt+F4 follow the same UI confirmation as the header Exit button.
  // Only the existing confirmed 'ta-exit' IPC may finish closing the window.
  mainWindow.on('close', event => {
    if (exitConfirmed) return;
    event.preventDefault();
    emit('ta-request-exit', {});
  });
  mainWindow.on('closed',()=>{mainWindow=null; lan?.stop(false);});
  const menu=Menu.buildFromTemplate([
    {label:'ملف',submenu:[
      {label:'إعدادات الطابعة وقارئ الباركود',accelerator:'Ctrl+Shift+P',click:()=>emit('ta-devices-open',{})},
      {label:'اختيار طابعة ويندوز',click:()=>choosePrinter().catch(()=>{})},
      {label:'البدء بمسح باركود USB',accelerator:'Ctrl+Shift+B',click:()=>emit('ta-scanner-open',{})},
      {label:'طباعة الصفحة (A4 أو عادية)',accelerator:'Ctrl+P',click:()=>printWindowsPage(false).catch(err=>notice(err.message,'error'))},
      {type:'separator'},
      {label:'إغلاق',click:()=>emit('ta-request-exit',{})}]},
    {label:'عرض',submenu:[{role:'reload',label:'إعادة تحميل'},{label:'تكبير / استعادة النافذة (F11)',accelerator:'F11',click:()=>{
      if(!mainWindow || mainWindow.isDestroyed())return;
      if(mainWindow.isMaximized())mainWindow.unmaximize(); else mainWindow.maximize();
    }},
      {role:'resetZoom',label:'حجم طبيعي'},{role:'zoomIn',label:'تكبير'},{role:'zoomOut',label:'تصغير'}]},
    {label:'مساعدة',submenu:[{label:'عن التطبيق',click:()=>notice('Tiqany Acc Manager 3.5.72\nنسخة ويندوز من التطبيق الرئيسي مع مزامنة محلية للمندوبين.')}]}]
  );
  Menu.setApplicationMenu(menu);
  await mainWindow.loadURL('tiqany://app/index.html');
}

if (single) {
  app.on('second-instance',()=>{if(mainWindow){if(mainWindow.isMinimized())mainWindow.restore();mainWindow.focus();}});
  app.whenReady().then(async()=>{
    // Stable installation-independent storage location: survives app updates.
    const userData=persistentUserData;
    configPath=path.join(userData,'desktop-printer.json');readConfig();
    protocol.handle('tiqany',request=>{
      try {
        const u=new URL(request.url);
        if (u.hostname!=='app') return new Response('Forbidden',{status:403});
        const file=path.resolve(webRoot,'.'+decodeURIComponent(u.pathname));
        if (file!==webRoot && !file.startsWith(webRoot+path.sep))return new Response('Forbidden',{status:403});
        return electronNet.fetch(pathToFileURL(file).toString());
      } catch (_) {return new Response('Invalid path',{status:400});}
    });
    lan=new ManagerLanServer({onRequest:payload=>emit('ta-lan-request',payload),onStatus:status=>emit('ta-lan-status',status)});
    peerLan=new PeerLanServer({userData,onRequest:payload=>emit('ta-peer-request',payload),onStatus:status=>emit('ta-peer-status',status)});
    peerLan.start();
    backup=new BackupService(userData,status=>emit('ta-backup-status',status));
    handlers();
    await createWindow();
  }).catch(err=>{dialog.showErrorBox('Tiqany Acc Manager',String(err));app.quit();});
  app.on('window-all-closed',()=>app.quit());
  app.on('before-quit',()=>{lan?.stop(false);peerLan?.stop();backup?.dispose();});
}
