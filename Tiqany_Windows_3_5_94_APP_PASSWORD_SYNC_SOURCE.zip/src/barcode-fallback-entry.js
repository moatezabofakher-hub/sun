/* Offline camera barcode scanner: this file is bundled by esbuild during Windows packaging.
   ZXing is shipped inside the application; no CDN or internet is used for scanning. */
import { BrowserMultiFormatReader } from '@zxing/browser';

const active = new Set();
window.TiqanyZXingCamera = Object.freeze({
  async start(video, onCode) {
    if (!(video instanceof HTMLVideoElement)) throw new Error('Camera preview is missing');
    const reader = new BrowserMultiFormatReader();
    let running = true;
    let controls;
    const stop = () => {
      if (!running) return;
      running = false;
      try { controls?.stop(); } catch (_) {}
      if (video.srcObject && typeof video.srcObject.getTracks === 'function') {
        video.srcObject.getTracks().forEach(track => track.stop());
      }
      video.srcObject = null;
      active.delete(stop);
    };
    active.add(stop);
    try {
      controls = await reader.decodeFromVideoDevice(undefined, video, result => {
        if (!running || !result) return;
        const code = String(result.getText?.() ?? '').trim();
        if (code) onCode(code);
      });
      if (!running) controls?.stop();
      return { stop };
    } catch (error) {
      stop();
      throw error;
    }
  },
  stopAll() {for (const stop of [...active]) stop();}
});
