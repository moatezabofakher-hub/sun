'use strict';
const { contextBridge, ipcRenderer } = require('electron');

const bridge = {
  onLanRequest: fn => ipcRenderer.on('ta-lan-request', (_event, value) => fn(value)),
  onLanStatus: fn => ipcRenderer.on('ta-lan-status', (_event, value) => fn(value)),
  onPrinterStatus: fn => ipcRenderer.on('ta-printer-status', (_event, value) => fn(value)),
  onBackupStatus: fn => ipcRenderer.on('ta-backup-status', (_event, value) => fn(value)),
  onBarcodeResult: fn => ipcRenderer.on('ta-barcode-result', (_event, value) => fn(value)),
  onDevicesOpen: fn => ipcRenderer.on('ta-devices-open', () => fn()),
  onScannerOpen: fn => ipcRenderer.on('ta-scanner-open', () => fn()),
  onExitRequested: fn => ipcRenderer.on('ta-request-exit', () => fn()),
  onDeviceConfig: fn => ipcRenderer.on('ta-device-config', (_event, value) => fn(value)),
  onPeerRequest: fn => ipcRenderer.on('ta-peer-request', (_event, value) => fn(value)),
  onPeerStatus: fn => ipcRenderer.on('ta-peer-status', (_event, value) => fn(value)),
  isWindowsDesktop: process.platform === 'win32'
};
contextBridge.exposeInMainWorld('WindowsDesktop', Object.freeze(bridge));
contextBridge.exposeInMainWorld('WindowsDevices', Object.freeze({
  settings: () => ipcRenderer.invoke('ta-devices-get'),
  printers: () => ipcRenderer.invoke('ta-devices-printers'),
  saveSettings: config => ipcRenderer.invoke('ta-devices-save', config),
  testPrinter: () => ipcRenderer.invoke('ta-devices-test'),
  printPage: silent => ipcRenderer.invoke('ta-devices-print-page', !!silent),
  printInvoice: data => ipcRenderer.invoke('ta-devices-print-invoice', data)
}));

// Keep the original Android JS bridge signature so field agents need no new APK.
contextBridge.exposeInMainWorld('AndroidLocalSync', Object.freeze({
  receiverEndpoint: () => ipcRenderer.sendSync('ta-lan-endpoint'),
  startReceiver: id => ipcRenderer.sendSync('ta-lan-start', String(id)),
  restartReceiver: id => ipcRenderer.sendSync('ta-lan-restart', String(id)),
  stopReceiver: () => ipcRenderer.send('ta-lan-stop'),
  reply: (requestId, encryptedReply) => ipcRenderer.send('ta-lan-reply', String(requestId), String(encryptedReply))
}));
contextBridge.exposeInMainWorld('AndroidFiles', Object.freeze({
  saveBackup: (raw, name) => ipcRenderer.send('ta-save-backup', String(raw), String(name))
}));
contextBridge.exposeInMainWorld('AndroidReports', Object.freeze({
  shareReport: (json, name) => ipcRenderer.send('ta-pdf', 'report', String(json), String(name))
}));
contextBridge.exposeInMainWorld('AndroidInvoicePdf', Object.freeze({
  shareInvoice: (json, name) => ipcRenderer.send('ta-pdf', 'invoice', String(json), String(name))
}));
contextBridge.exposeInMainWorld('AndroidPrinter', Object.freeze({
  choosePrinter: () => ipcRenderer.send('ta-printer-choose'),
  printBase64: b64 => ipcRenderer.send('ta-printer-print', String(b64))
}));
contextBridge.exposeInMainWorld('AndroidAutoBackup', Object.freeze({
  getStatus: () => ipcRenderer.sendSync('ta-backup-status-get'),
  stageSnapshot: raw => ipcRenderer.send('ta-backup-stage', String(raw)),
  configure: (kind, enabled, hours) => ipcRenderer.sendSync('ta-backup-configure', String(kind), !!enabled, Number(hours)),
  chooseLocalFolder: () => ipcRenderer.send('ta-backup-folder'),
  connectDrive: () => ipcRenderer.send('ta-backup-drive'),
  runNow: kind => ipcRenderer.send('ta-backup-now', String(kind))
}));
contextBridge.exposeInMainWorld('Android', Object.freeze({
  getAppVersionName: () => require('../package.json').version,
  exitApp: () => ipcRenderer.send('ta-exit'),
  closeApp: () => ipcRenderer.send('ta-exit')
}));
// Native fingerprint remains intentionally unavailable rather than bypassed.

contextBridge.exposeInMainWorld('WindowsPeerSync', Object.freeze({
  config: () => ipcRenderer.invoke('ta-peer-config'),
  reply: (id, response) => ipcRenderer.send('ta-peer-reply', String(id), JSON.stringify(response))
}));
