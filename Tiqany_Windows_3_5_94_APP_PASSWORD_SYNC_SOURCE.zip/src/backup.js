'use strict';
const fs = require('node:fs');
const path = require('node:path');

function safeFilename(raw, fallback = 'TiqanyBackup.json') {
  const n = String(raw || '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 130).trim();
  return n || fallback;
}

class BackupService {
  constructor(directory, onChange = () => {}) {
    this.directory = directory;
    this.onChange = onChange;
    fs.mkdirSync(directory, { recursive: true });
    this.configFile = path.join(directory, 'backup-settings.json');
    this.snapshotFile = path.join(directory, 'last-snapshot.json');
    this.config = { localEnabled: false, localHours: 24, localFolder: '', localLast: 0,
      localError: '', snapshotAt: 0, snapshotError: '' };
    try { Object.assign(this.config, JSON.parse(fs.readFileSync(this.configFile,'utf8'))); } catch (_) {}
    this.pendingStage = Promise.resolve();
    this.snapshot = null;
    this.timer = setInterval(() => this.maybeBackup(), 60_000);
    this.timer.unref?.();
  }
  status() {
    return { supported: true, localEnabled: !!this.config.localEnabled,
      localHours: Number(this.config.localHours)||24,
      localFolderConfigured: !!this.config.localFolder,
      driveEnabled: false, driveHours: 24, driveConnected: false,
      localLast: this.config.localLast || 0, driveLast: 0,
      localError: this.config.localError || '', driveError: 'Google Drive غير متاح في نسخة ويندوز الحالية',
      snapshotAt: this.config.snapshotAt || 0, snapshotError: this.config.snapshotError || '' };
  }
  persist() { fs.writeFileSync(this.configFile, JSON.stringify(this.config, null, 2), 'utf8'); this.onChange(this.status()); }
  configure(kind, enabled, hours) {
    if (kind !== 'local') return 'النسخ إلى Google Drive غير مدعوم بعد في نسخة ويندوز. استخدم النسخ المحلي.';
    if (!Number.isFinite(hours) || hours < 1 || hours > 720) return 'الفترة يجب أن تكون من ساعة إلى 720 ساعة';
    if (enabled && !this.config.localFolder) return 'اختر مجلد النسخ الاحتياطي أولاً';
    this.config.localEnabled = !!enabled;
    this.config.localHours = hours;
    this.persist();
    return '';
  }
  setFolder(folder) {
    if (!fs.statSync(folder).isDirectory()) throw Error('المجلد المختار غير صالح');
    this.config.localFolder = folder;
    this.persist();
  }
  stageSnapshot(raw) {
    if (typeof raw !== 'string' || raw.length > 160_000_000) {
      this.config.snapshotError = 'حجم النسخة غير صالح'; this.persist(); return;
    }
    let parsed;
    try {parsed = JSON.parse(raw);} catch (_) {this.config.snapshotError = 'بيانات النسخ غير صالحة';this.persist();return;}
    if (parsed?.app !== 'AlRaedAccountingERP' || !parsed?.data || typeof parsed.data !== 'object') {
      this.config.snapshotError = 'صيغة النسخة غير معروفة';this.persist();return;
    }
    this.snapshot = raw;
    this.pendingStage = this.pendingStage.then(async () => {
      const temp = this.snapshotFile + '.pending';
      await fs.promises.writeFile(temp, raw, { encoding: 'utf8', mode: 0o600 });
      await fs.promises.rename(temp, this.snapshotFile);
      this.config.snapshotAt = Date.now();
      this.config.snapshotError = '';
      this.persist();
    }).catch(e => { this.config.snapshotError = e.message;this.persist(); });
  }
  async maybeBackup() {
    if (!this.config.localEnabled || !this.config.localFolder) return;
    if (Date.now() - Number(this.config.localLast || 0) < this.config.localHours * 3600_000) return;
    await this.runNow('local');
  }
  async runNow(kind) {
    if (kind !== 'local' || !this.config.localEnabled || !this.config.localFolder) return false;
    await this.pendingStage;
    try {
      const raw = this.snapshot || await fs.promises.readFile(this.snapshotFile, 'utf8');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const dest = path.join(this.config.localFolder, 'Tiqany-Acc-' + timestamp + '.json');
      await fs.promises.writeFile(dest, raw, { encoding:'utf8', flag: 'wx', mode:0o600 });
      this.config.localLast = Date.now();
      this.config.localError = '';
      this.persist();return true;
    } catch(e) {this.config.localError = String(e.message);this.persist();return false;}
  }
  dispose() { clearInterval(this.timer); }
}
module.exports = { BackupService, safeFilename };
