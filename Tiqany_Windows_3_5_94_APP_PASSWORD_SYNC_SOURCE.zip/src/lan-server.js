'use strict';
// TCP framing mirrors NativeLocalSync.java exactly: 4-byte big-endian length + UTF-8 JSON.
// The renderer's FieldSync logic still authenticates, decrypts, deduplicates and commits.
const net = require('node:net');
const { randomUUID } = require('node:crypto');
const MAX_FRAME = 7_800_000;
const VALID_COMPANY = /^company_[A-Za-z0-9_-]{8,128}$/;
const REPLY_TIMEOUT = 38_000;

function frame(raw) {
  if (typeof raw !== 'string') throw Error('Response must be text');
  const body = Buffer.from(raw, 'utf8');
  if (!body.length || body.length > MAX_FRAME) throw Error('Frame size outside limits');
  const out = Buffer.allocUnsafe(4 + body.length);
  out.writeUInt32BE(body.length, 0); body.copy(out, 4);
  return out;
}

class ManagerLanServer {
  constructor({ onRequest, onStatus, BonjourClass } = {}) {
    this.onRequest = onRequest || (() => {});
    this.onStatus = onStatus || (() => {});
    this.BonjourClass = BonjourClass || require('bonjour-service').Bonjour;
    this.pending = new Map();
    this.server = null;
    this.bonjour = null;
    this.service = null;
    this.company = null;
    this.activeSockets = new Set();
  }
  start(company, force = false) {
    if (!VALID_COMPANY.test(String(company))) return 'invalid';
    if (!force && this.server && this.company === company) return 'already';
    this.stop(false);
    this.company = company;
    const server = net.createServer({ allowHalfOpen: false }, socket => this._client(socket));
    this.server = server;
    server.on('error', e => { if (this.server === server) this.onStatus('تعذر استقبال Wi-Fi: ' + e.message); });
    server.listen(0, '0.0.0.0', () => {
      if (this.server !== server) return;
      try {
        this.bonjour = new this.BonjourClass();
        // Android NSD discovers _taaccount._tcp with name TA-FIELD-<company suffix>.
        this.service = this.bonjour.publish({
          name: 'TA-FIELD-' + company.slice(-12), type: 'taaccount', protocol: 'tcp',
          port: server.address().port
        });
        if (this.service?.on) this.service.on('error', e => this.onStatus('فشل إعلان استقبال Wi-Fi: ' + e.message));
        this.onStatus('ready');
      } catch (e) { this.onStatus('فشل إعلان استقبال Wi-Fi: ' + e.message); }
    });
    return 'starting';
  }
  _client(socket) {
    this.activeSockets.add(socket);
    socket.setTimeout(45_000);
    let readBuffer = Buffer.alloc(0), size = -1;
    let dispatched = false, requestId;
    const close = () => {
      this.activeSockets.delete(socket);
      if (requestId) {
        const entry = this.pending.get(requestId);
        if (entry) { clearTimeout(entry.timer); this.pending.delete(requestId); }
      }
    };
    socket.on('close', close);
    socket.on('timeout', () => socket.destroy());
    socket.on('error', () => socket.destroy());
    socket.on('data', chunk => {
      if (dispatched) { socket.destroy(); return; }
      readBuffer = Buffer.concat([readBuffer, chunk]);
      if (size === -1 && readBuffer.length >= 4) {
        size = readBuffer.readUInt32BE(0);
        if (size === 0 || size > MAX_FRAME) { socket.destroy(); return; }
      }
      if (size !== -1 && readBuffer.length > size + 4) { socket.destroy(); return; }
      if (size !== -1 && readBuffer.length === size + 4) {
        dispatched = true;
        const raw = readBuffer.subarray(4).toString('utf8');
        requestId = randomUUID();
        const timer = setTimeout(() => {
          if (this.pending.has(requestId)) this.reply(requestId, JSON.stringify({ error: 'انتهت مهلة الاستجابة من التطبيق الرئيسي' }));
        }, REPLY_TIMEOUT);
        this.pending.set(requestId, { socket, timer });
        const pairing = raw.length <= 12_000 && raw.includes('"pairingProtocol":"TA-PAIR-1"');
        try { this.onRequest({ requestId, raw, pairing }); }
        catch (e) { this.reply(requestId, JSON.stringify({ error: 'تعذر استقبال الطلب' })); }
      }
    });
  }
  reply(id, raw) {
    const entry = this.pending.get(String(id));
    if (!entry) return false;
    this.pending.delete(String(id));
    clearTimeout(entry.timer);
    try {
      entry.socket.end(frame(raw));
      return true;
    } catch (e) { entry.socket.destroy(); return false; }
  }
  stop(report = true) {
    this.company = null;
    for (const item of this.pending.values()) { clearTimeout(item.timer); item.socket.destroy(); }
    this.pending.clear();
    for (const socket of this.activeSockets) socket.destroy();
    this.activeSockets.clear();
    try { this.service?.stop(); } catch (_) {}
    this.service = null;
    try { this.bonjour?.destroy(); } catch (_) {}
    this.bonjour = null;
    try { this.server?.close(); } catch (_) {}
    this.server = null;
    if (report) this.onStatus('stopped');
  }
}
module.exports = { ManagerLanServer, frame, MAX_FRAME, VALID_COMPANY };
