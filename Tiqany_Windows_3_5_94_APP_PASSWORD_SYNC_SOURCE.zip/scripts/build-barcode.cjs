'use strict';
// Build an OFFLINE browser bundle for Electron. No API keys and no remote barcode service.
const path = require('node:path');
const esbuild = require('esbuild');
const root = path.resolve(__dirname, '..');
esbuild.buildSync({
  entryPoints: [path.join(root,'src/barcode-fallback-entry.js')],
  bundle: true, format: 'iife', platform: 'browser',
  target: ['chrome125'], minify: true, legalComments: 'inline',
  outfile: path.join(root,'web/static/tiqany-zxing-camera.js'),
  sourcemap: false
});
console.log('Bundled offline camera barcode reader into web/static/tiqany-zxing-camera.js');
