param(
  [Parameter(Mandatory = $true)][string] $PrinterName,
  [Parameter(Mandatory = $true)][string] $InputFile
)
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class RawPrinter {
  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
  public struct DOCINFO { [MarshalAs(UnmanagedType.LPWStr)] public string pDocName; [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile; [MarshalAs(UnmanagedType.LPWStr)] public string pDataType; }
  [DllImport("winspool.drv", EntryPoint="OpenPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern bool OpenPrinter(string name, out IntPtr printer, IntPtr def);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool ClosePrinter(IntPtr printer);
  [DllImport("winspool.drv", EntryPoint="StartDocPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern uint StartDocPrinter(IntPtr printer, int level, ref DOCINFO info);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndDocPrinter(IntPtr printer);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool StartPagePrinter(IntPtr printer);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndPagePrinter(IntPtr printer);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool WritePrinter(IntPtr printer, byte[] buffer, int length, out int written);
}
'@
$bytes = [System.IO.File]::ReadAllBytes($InputFile)
if ($bytes.Length -eq 0 -or $bytes.Length -gt 8000000) { throw 'Invalid print buffer size' }
$handle = [IntPtr]::Zero
if (-not [RawPrinter]::OpenPrinter($PrinterName, [ref]$handle, [IntPtr]::Zero)) { throw 'Printer not found in Windows' }
$docStarted = $false; $pageStarted = $false
try {
  $info = New-Object RawPrinter+DOCINFO
  $info.pDocName = 'Tiqany Acc Invoice'; $info.pDataType = 'RAW'
  if ([RawPrinter]::StartDocPrinter($handle, 1, [ref]$info) -eq 0) { throw 'Windows print job failed' }
  $docStarted = $true
  if (-not [RawPrinter]::StartPagePrinter($handle)) { throw 'Printer page failed' }
  $pageStarted = $true
  $written = 0
  if (-not [RawPrinter]::WritePrinter($handle, $bytes, $bytes.Length, [ref]$written) -or $written -ne $bytes.Length) { throw 'Incomplete printer write' }
} finally {
  if ($pageStarted) { [void][RawPrinter]::EndPagePrinter($handle) }
  if ($docStarted) { [void][RawPrinter]::EndDocPrinter($handle) }
  [void][RawPrinter]::ClosePrinter($handle)
}
