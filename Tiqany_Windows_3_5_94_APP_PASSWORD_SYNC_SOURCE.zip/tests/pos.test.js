'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(root,'web/static/windows-pos.js'),'utf8');
const html=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
function env(){
  const item={id:'it1',name:'سائل جلي ليمون',barcode:'10001',category:'منظفات',currency:'USD',units:[{name:'عبوة',factor:1,wholesalePrice:5,centerPrice:6,consumerPrice:8,salePrice:5}]};
  const state={settings:{posPriceTier:'consumer',posAccountId:'',defaultPriceTier:'wholesale',selectedWarehouseId:'wh_main'},accounts:[],items:[item],categories:['منظفات'],warehouses:[{id:'wh_main'}],invoices:[]};
  const draft={type:'sale',accountId:'',currency:'USD',exchangeRate:15000,paymentMethod:'cash',warehouseId:'wh_main',rows:[]};
  let persisted=0,markCalls=0;
  const ctx={State:state,AppEscape:{text:s=>String(s)},AppNav:{current:()=>({screen:'pos'}),markDirty:()=>{markCalls++;},clearDirty:()=>{},enableOperationGuard:()=>{}},
    InvoiceController:{draft,addItemToInvoice(id){draft.rows.push({itemId:id,itemName:item.name,unitName:'عبوة',qty:1,price:5,basePrice:5,baseCurrency:'USD'});},recalculate(){let total=0;for(const row of draft.rows){row.total=row.qty*row.price;total+=row.total;}draft.netTotal=total;},renderForm(){}},
    Accounting:{itemSalePrice(_itm,unit,_acc,tier){return tier==='consumer'?unit.consumerPrice:tier==='center'?unit.centerPrice:unit.wholesalePrice;},convert(x){return x;},parseNum(x){return Number(x)},format(x){return String(x)},getItemBaseStock(){return 10}},
    document:{getElementById(id){if(id==='posAccountSetting')return {value:'cust1'};if(id==='posTierSetting')return {value:'center'};return {};}},
    StorageEngine:{async saveState(){persisted++;}},UI:{toast(){}},setTimeout(){},window:{}};
  vm.createContext(ctx);vm.runInContext(source+'\n;globalThis.__POS=POSController;',ctx);
  ctx.__POS.paint=()=>{};
  return {pos:ctx.__POS,ctx,item,draft,state,counts:()=>({persisted,markCalls})};
}
test('POS is integrated into home, route, and invoice-settings view',()=>{
  assert.match(html,/case 'pos': return POSController\.render/);
  assert.match(html,/AppNav\.navigate\('pos'\)/);
  assert.match(html,/id="posAccountSetting"/);
  assert.match(html,/id="posTierSetting"/);
});
test('POS allows cash customer and dedicated customer / price-tier settings',async()=>{
  const x=env();
  assert.equal(x.pos.accountId(),'');
  x.state.accounts.push({id:'cust1',name:'زبون خاص',type:'customer'});
  await x.pos.saveSettings();
  assert.equal(x.state.settings.posAccountId,'cust1');
  assert.equal(x.state.settings.posPriceTier,'center');
  assert.equal(x.pos.accountId(),'cust1');
  assert.equal(x.counts().persisted,1);
});
test('POS adds repeat scans as quantity and applies POS-only price tier',()=>{
  const x=env();
  x.pos.add('it1');x.pos.add('it1');x.pos.addBarcode('10001');
  assert.equal(x.draft.rows.length,1);
  assert.equal(x.draft.rows[0].qty,3);
  assert.equal(x.draft.rows[0].price,8);
  assert.equal(x.draft.netTotal,24);
  assert.equal(x.state.settings.defaultPriceTier,'wholesale');
  assert.equal(x.counts().markCalls,3);
});
test('POS name and barcode searching filters the same items without changing data',()=>{
  const x=env();
  x.pos.query='ليمون';
  assert.equal(x.pos.shownItems().length,1);
  x.pos.query='غير موجود';
  assert.equal(x.pos.shownItems().length,0);
  x.pos.query='10001';
  assert.equal(x.pos.shownItems().length,1);
  assert.equal(x.state.items.length,1);
});
