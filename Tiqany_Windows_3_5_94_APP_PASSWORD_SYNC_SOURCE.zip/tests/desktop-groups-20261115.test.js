const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const code=fs.readFileSync('web/index.html','utf8');
const styles=fs.readFileSync('web/static/desktop-dense-dashboard.css','utf8');
const pos=fs.readFileSync('web/static/windows-pos.js','utf8');
test('desktop home has three grouped sections with report print entry in Reports',()=>{
  const block=code.slice(code.indexOf('renderDashboard(main) {'),code.indexOf('// ==================== 6.2 ITEMS'));
  for(const name of ['الفواتير ونقطة البيع','السندات والصندوق','الإدارة والمستودعات'])assert.ok(block.includes(name),name);
  for(const action of ['pos','invoice_form','voucher_form','vouchers_list','items','warehouses','expenses','invoices_list']) assert.ok(block.includes(action),action);
  for(const cls of ['ta-home-invoices','ta-home-vouchers','ta-home-manage'])assert.ok(block.includes(cls));
  assert.match(block,/data-pos-prominent="true"/);
  assert.ok(!block.includes('تقرير المواد') && !block.includes('تقرير الديون'), 'report shortcuts moved off dashboard');
  assert.ok(code.includes('LedgerReports.openPrintChooser()'), 'Report printing remains on Reports screen');
});
test('dark grouped layout has viewport fit and compact fallback',()=>{
  assert.match(code,/static\/desktop-dense-dashboard.css/);
  assert.match(styles,/100dvh/);
  assert.match(styles,/grid-template-columns/);
  assert.match(styles,/max-height:650px/);
  assert.match(styles,/linear-gradient/);
});
test('POS auto-next setting is configurable with explicit blank exit behavior',()=>{
  assert.match(code,/id="posAutoNextSetting"/);
  assert.match(code,/InvoiceController\.draft\?\.rows\?\.length>0/);
  assert.match(pos,/State\.settings\.posAutoNextOnFinish=proposedNext/);
  assert.match(pos,/else if\(State\.settings\.posAutoNextOnFinish!==false\)/);
});
