'use strict';
const test=require('node:test'), assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
test('beep happens on scanner decoding, not invoice insert / POS add',()=>{
 const html=read('web/index.html');const pos=read('web/static/windows-pos.js');
 const devices=read('web/static/desktop-peripherals.js');
 const audio=read('web/static/barcode-feedback.js');
 assert.match(html,/static\/barcode-feedback\.js/);
 assert.match(devices,/BarcodeFeedback\?\.read\(window\.BarcodeFeedback\?\.isKnown\(normalized\)/);
 assert.match(html,/BarcodeFeedback\?\.read\(window\.BarcodeFeedback\?\.isKnown\(value\)/);
 assert.doesNotMatch(pos,/BarcodeFeedback\?\.success/);
 assert.doesNotMatch(html,/BarcodeFeedback\?\.success/);
 assert.match(audio,/read\(known=true\)/);assert.match(audio,/createOscillator/);assert.match(audio,/tone\(context,360/);
});
