'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const PurchaseCosting=require('../web/static/purchase-costing.js');
const item=(id,cost=20,currency='USD')=>({id,name:id,currency,units:[
  {name:'كرتونة',factor:1,costPrice:cost,salePrice:100,centerPrice:110,consumerPrice:120},
  {name:'قطعة',factor:12,costPrice:cost/12,salePrice:100/12,centerPrice:110/12,consumerPrice:120/12}
]});
const row=(itemId,price,qty=1,extra={})=>({itemId,itemName:itemId,qty,price,unitName:'كرتونة',unitFactor:1,discount:0,purchaseAddAmount:0,total:qty*price,...extra});
const inv=(id,date,rows,extras={})=>({id,date,number:1,type:'purchase',currency:'USD',exchangeRate:15000,rows,
  subTotal:rows.reduce((t,r)=>t+r.total,0),discountAmount:0,taxAmount:0,...extras});
const almost=(actual,expected,tol=1e-7)=>assert.ok(Math.abs(actual-expected)<=tol,`${actual} differs from ${expected}`);

test('last purchase updates major and minor units, sales prices remain unchanged',()=>{
 const items=[item('x')],before=JSON.stringify(items[0].units.map(x=>[x.salePrice,x.centerPrice,x.consumerPrice]));
 const invoice=inv('p1','2026-11-01T10:00',[row('x',80,2)]);
 PurchaseCosting.reconcile(items,[invoice]);
 almost(items[0].units[0].costPrice,80);
 almost(items[0].units[1].costPrice,80/12);
 assert.equal(JSON.stringify(items[0].units.map(x=>[x.salePrice,x.centerPrice,x.consumerPrice])),before);
 assert.equal(items[0].lastPurchaseCost.invoiceId,'p1');
});

test('per-item and global discounts plus additions change actual cost',()=>{
 const items=[item('x')];
 // Base: 2 units × 100 − line discount 10 + line addition 5 =195
 // General discount 20 + general addition 15 -> net 190 -> per item 95.
 const purchase=inv('p','2026-11-01',[row('x',100,2,{discount:10,purchaseAddAmount:5,total:195})],{subTotal:195,discountAmount:20,taxAmount:15});
 assert.equal(PurchaseCosting.validInvoice(purchase),null);
 PurchaseCosting.reconcile(items,[purchase]);
 almost(items[0].units[0].costPrice,95);
});

test('global discount and addition are allocated proportional to item line values',()=>{
 const items=[item('a'),item('b')];
 const purchase=inv('p','2026-11-01',[row('a',100),row('b',300)],{discountAmount:40,taxAmount:20});
 PurchaseCosting.reconcile(items,[purchase]);
 almost(items[0].units[0].costPrice,95);
 almost(items[1].units[0].costPrice,285);
});

test('currency conversion uses saved purchase invoice rate rather than today',()=>{
 const items=[item('a',50,'SYP'),item('b',25,'USD')];
 const purchase=inv('p','2026-11-01',[row('a',2),row('b',20000)],{currency:'USD',exchangeRate:10000});
 PurchaseCosting.reconcile(items,[purchase]);
 almost(items[0].units[0].costPrice,20000);
 almost(items[1].units[0].costPrice,20000);
 const reverse=inv('p2','2026-11-02',[row('b',200000)],{currency:'SYP',exchangeRate:20000});
 PurchaseCosting.reconcile(items,[purchase,reverse]);
 almost(items[1].units[0].costPrice,10);
});

test('most recent purchase is selected by invoice date not last-edited order',()=>{
 const items=[item('x')];
 const later=inv('newer','2026-11-04T18:00',[row('x',25)]);
 const earlier=inv('older','2026-11-02T08:00',[row('x',70)]);
 PurchaseCosting.reconcile(items,[later,earlier]);
 almost(items[0].units[0].costPrice,25);
 earlier.rows[0].price=99;earlier.rows[0].total=99;
 PurchaseCosting.reconcile(items,[later,earlier]);
 almost(items[0].units[0].costPrice,25);
});

test('editing latest purchase updates cost without creating a second source',()=>{
 const items=[item('x')];
 const invoice=inv('same','2026-11-01',[row('x',20,2)],{discountAmount:10});
 PurchaseCosting.reconcile(items,[invoice]);almost(items[0].units[0].costPrice,15);
 invoice.discountAmount=20;
 PurchaseCosting.reconcile(items,[invoice]);almost(items[0].units[0].costPrice,10);
});

test('deleting latest purchase returns to older cost; deleting all restores manually entered cost',()=>{
 const items=[item('x',11)];
 const old=inv('older','2026-11-01',[row('x',30)]);
 const current=inv('later','2026-11-02',[row('x',60)]);
 PurchaseCosting.reconcile(items,[old,current]);almost(items[0].units[0].costPrice,60);
 PurchaseCosting.reconcile(items,[old]);almost(items[0].units[0].costPrice,30);
 PurchaseCosting.reconcile(items,[]);almost(items[0].units[0].costPrice,11);
 assert.equal(items[0].lastPurchaseCost,undefined);
 assert.equal(Object.hasOwn(items[0].units[0],'manualCostBeforePurchase'),false);
});

test('multiple units and purchase invoice repeated lines are costed by base quantity',()=>{
 const items=[item('x')];
 // 12 pieces @ $2 + 1 carton @ $48 => 2 cartons of stock costing $72.
 const r1=row('x',2,12,{unitName:'قطعة',unitFactor:12,total:24});
 const r2=row('x',48,1,{total:48});
 PurchaseCosting.reconcile(items,[inv('p','2026-11-02',[r1,r2])]);
 almost(items[0].units[0].costPrice,36);
 almost(items[0].units[1].costPrice,3);
});

test('zero-valued products can absorb a shared purchase addition by quantities',()=>{
 const items=[item('x')];
 const purchase=inv('p','2026-11-04',[row('x',0,4)],{taxAmount:12});
 PurchaseCosting.reconcile(items,[purchase]);
 almost(items[0].units[0].costPrice,3);
});

test('invalid purchase discount or addition is rejected by validator',()=>{
 const tooBig=inv('p','2026-11-04',[row('x',50)],{discountAmount:60});
 assert.match(PurchaseCosting.validInvoice(tooBig),/الحسم العام/);
 const badRow=inv('p','2026-11-04',[row('x',50,1,{discount:51,total:0})]);
 assert.match(PurchaseCosting.validInvoice(badRow),/حسم المادة/);
 const negative=inv('p','2026-11-04',[row('x',50)],{taxAmount:-10});
 assert.match(PurchaseCosting.validInvoice(negative),/الإضافات/);
});

test('repeated recomputations are idempotent and original manual baseline preserved',()=>{
 const items=[item('x',20)];const purchase=inv('p','2026-11-04',[row('x',45)]);
 PurchaseCosting.reconcile(items,[purchase]);
 const before=JSON.stringify(items);
 PurchaseCosting.reconcile(items,[purchase]);
 assert.equal(JSON.stringify(items),before);
});

test('sales invoice cost snapshot, buying UI, saving and state reconciliation are wired',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
 assert.match(html,/static\/purchase-costing\.js/);
 assert.match(html,/PurchaseCosting\.reconcile\(State\.items, State\.invoices\)/);
 assert.match(html,/PurchaseCosting\.validInvoice\(d\)/);
 assert.match(html,/purchaseAddAmount/);
 assert.match(html,/baseCostPrice: item\.isBundle \? Accounting\.itemCostPrice\(item, unit0\) : Number\(unit0\.costPrice\)\|\|0/);
 assert.match(html,/Number\(r\.baseCostPrice \?\? Accounting\.itemCostPrice\(item,unitObj\)\)/);
});
