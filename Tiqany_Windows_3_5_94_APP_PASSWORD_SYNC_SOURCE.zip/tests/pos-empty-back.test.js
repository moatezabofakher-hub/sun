const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
const pos=fs.readFileSync(path.join(__dirname,'../web/static/windows-pos.js'),'utf8');
test('blank invoice or POS exits without unsaved dialog while populated invoices retain protection',()=>{
 const back=html.slice(html.indexOf('handleBackButton() {'),html.indexOf('// On the home screen',html.indexOf('handleBackButton() {')));
 assert.match(back,/\['invoice_form','pos'\]\.includes\(this\.current\(\)\?\.screen\)/);
 assert.match(back,/!InvoiceController\.draft\?\.rows\?\.length/);
 assert.ok(back.indexOf('this.popScreen();')<back.indexOf('UI.showUnsavedDialog('));
 assert.match(back,/if \(this\.isDirty \|\| this\.activeOperationGuard\)/);
});
test('successful POS invoice opens a new transaction without duplicate save',()=>{
 assert.match(pos,/if\(this\.saving\)return false/);
 assert.match(pos,/const ok=await InvoiceController\.saveInvoice\(false\)/);
 assert.match(pos,/if\(!ok\)return false/);
 assert.match(pos,/AppNav\.navigate\('pos',\{\},true\)/);
});
