'use strict';
const {test} = require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
test('offline manager QR renders a valid matrix without network or secrets',()=>{
 const context={};context.window=context;context.globalThis=context;
 vm.runInNewContext(fs.readFileSync(path.join(root,'web/static/tiqany-qr.js'),'utf8'),context);
 const qr='tiqany-pair://local?v=1&company=company_0123456789abcdef&host=192.168.1.11&port=40645';
 const matrix=context.TiqanyQr.matrix(qr);
 assert.ok(matrix.length>=21);assert.equal(matrix.length,matrix[0].length);
 assert.match(context.TiqanyQr.svg(qr),/<svg/);
 assert.doesNotMatch(qr,/token|secret|password|key=/i);
});
test('cloud relay never routes raw packets around manager ledger verification',()=>{
 const manager=fs.readFileSync(path.join(root,'web/static/field-main.js'),'utf8');
 const cloud=fs.readFileSync(path.join(root,'web/static/tiqany-cloud-manager.js'),'utf8');
 const preload=fs.readFileSync(path.join(root,'src/preload.js'),'utf8');
 assert.match(manager,/FieldLanCrypto\.open\(packet,agent\.key/);
 assert.match(manager,/commitLanOperations\(agent,fresh\)/);
 assert.match(manager,/startsWith\('cloud:'\)/);
 assert.match(cloud,/receiveLanPacket\('cloud:'/);
 assert.match(cloud,/https:/);
 assert.match(preload,/receiverEndpoint/);
});
