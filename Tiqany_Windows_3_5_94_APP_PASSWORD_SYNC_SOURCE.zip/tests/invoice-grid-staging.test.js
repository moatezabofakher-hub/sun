const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');
const html=fs.readFileSync('web/index.html','utf8');
test('invoice grid stages selections and shows a live Add count before modifying invoice',()=>{
 assert.match(html,/id="itemGridApplyButton"/);
 assert.match(html,/gridSelectionCount\(\)/);
 assert.match(html,/this\.gridPending\[itemId\] = Number\(this\.gridPending\[itemId\] \|\| 0\) \+ 1/);
 assert.match(html,/applyGridSelection\(\)/);
 assert.match(html,/for \(const \[itemId, quantity\] of chosen\)/);
 assert.match(html,/UI\.forceCloseModal\(\);\s*this\.gridPending = Object\.create\(null\)/);
 assert.ok(!html.includes('إغلاق الشبكة (${this.draft.rows.length} أصناف بالفاتورة)'));
});
