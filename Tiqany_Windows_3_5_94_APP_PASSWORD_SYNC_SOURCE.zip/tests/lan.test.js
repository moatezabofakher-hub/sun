'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const net = require('node:net');
const { ManagerLanServer, frame } = require('../src/lan-server');
class FakeBonjour { publish(info) {this.info=info;return { stop() {}, on() {} };} destroy() {} }

test('framing uses compatible big-endian length',()=>{
  const b=frame('سلام');
  assert.equal(b.readUInt32BE(0),Buffer.byteLength('سلام'));
  assert.equal(b.subarray(4).toString('utf8'),'سلام');
  assert.throws(()=>frame(''));
});
test('LAN agent request / response + pairing transport',async()=>{
  const packets=[];
  const server = new ManagerLanServer({BonjourClass:FakeBonjour, onRequest:x=>{packets.push(x);server.reply(x.requestId,'{"ack":true}');},onStatus:()=>{}});
  assert.equal(server.start('bad'),'invalid');
  assert.equal(server.start('company_AAAAAAAAAAAA'),'starting');
  await new Promise(resolve=>server.server.once('listening',resolve));
  assert.equal(server.start('company_AAAAAAAAAAAA'),'already');
  assert.equal(server.bonjour.info.type,'taaccount');
  assert.equal(server.bonjour.info.name,'TA-FIELD-AAAAAAAAAAAA');
  const req='{"pairingProtocol":"TA-PAIR-1","kind":"hello"}';
  const result=await new Promise((resolve,reject)=>{
    const socket=net.connect(server.server.address().port,'127.0.0.1');
    const chunks=[];
    socket.on('connect',()=>socket.write(frame(req)));
    socket.on('data',chunk=>chunks.push(chunk));
    socket.on('end',()=>resolve(Buffer.concat(chunks)));
    socket.on('error',reject);
  });
  assert.equal(result.readUInt32BE(0),Buffer.byteLength('{"ack":true}'));
  assert.equal(result.subarray(4).toString('utf8'),'{"ack":true}');
  assert.equal(packets.length,1);
  assert.equal(packets[0].pairing,true);
  server.stop();
});
