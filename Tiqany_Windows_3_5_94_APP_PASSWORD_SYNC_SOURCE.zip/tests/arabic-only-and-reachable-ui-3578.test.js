const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const ui=fs.readFileSync(path.resolve(__dirname,'../web/index.html'),'utf8');
test('Arabic-only interface has no language toggle or translator runtime',()=>{
 assert.doesNotMatch(ui,/id="appLanguage"|data-settings-section="language"|I18n\.|static\/i18n\.js/);
 assert.match(ui,/<html lang="ar" dir="rtl">/);
});
test('Windows font size is independent from language settings',()=>{
 assert.match(ui,/data-settings-section="font_size"/);
 assert.match(ui,/id="appUiFontSize"/);
 assert.match(ui,/UiFontScale\.set\(this\.value\)/);
});
