'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const src = fs.readFileSync(path.resolve(__dirname,'../web/index.html'),'utf8');
const pkg = require('../package.json');
test('Invoice date is shown as ISO day + time, not locale-dependent datetime placeholders', () => {
  assert.match(src,/ta-invoice-date-visible/);
  assert.match(src,/visibleInvoiceDate\(d\.date\)\.day/);
  assert.match(src,/changeInvoiceDatePart\('day'/);
  assert.doesNotMatch(src,/type="datetime-local" value="\$\{d\.date\}" onchange="InvoiceController\.draft\.date/);
});
test('Invoice sale price tier is configurable per invoice while retaining manually set prices', () => {
  assert.match(src,/changeInvoicePricingTier\(tier\)/);
  assert.match(src,/row\.priceManuallySet\) continue/);
  assert.match(src,/option value="account"/);
  assert.match(src,/option value="consumer"/);
  assert.match(src,/Accounting\.itemSalePrice\(item,unit,this\.draft\.accountId,tier===/);
});
test('Camera barcode fallback bundles local ZXing and stops stream on closing', () => {
  assert.match(src,/static\/tiqany-zxing-camera\.js/);
  assert.match(src,/window\.TiqanyZXingCamera\.start/);
  assert.match(src,/barcodeScanControls\.stop\(\)/);
  assert.match(src,/itemBarcodeScanControls\.stop\(\)/);
  assert.equal(pkg.dependencies['@zxing/browser'].startsWith('^0.1.'),true);
  assert.match(pkg.scripts['build:win'],/build:barcode/);
});
