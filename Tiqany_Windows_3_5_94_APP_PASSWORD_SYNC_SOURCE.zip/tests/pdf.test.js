'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {reportHTML,invoiceHTML}=require('../src/pdf');
test('PDF HTML escapes user text',()=>{
  const x=reportHTML({companyName:'شركة <test>',rows:[{name:'<script>alert(1)</script>',detail:'100'}],totals:{USD:2,SYP:3}});
  assert.match(x,/&lt;script&gt;/);
  assert.ok(!x.includes('<script>alert(1)</script>'));
  assert.match(x,/الإجمالي بالليرة/);
});
test('Invoice shows only invoice-currency balance',()=>{
  const x=invoiceHTML({currency:'USD',rows:[],previousBalances:{USD:11,SYP:999999},finalBalances:{USD:20,SYP:999999}});
  assert.match(x,/11 USD/);
  assert.match(x,/20 USD/);
  assert.ok(!x.includes('999,999'));
  assert.ok(!x.includes('الرصيد النهائي (SYP)'));
});
