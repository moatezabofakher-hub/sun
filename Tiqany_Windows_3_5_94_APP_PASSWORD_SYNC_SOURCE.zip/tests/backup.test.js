'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {BackupService,safeFilename}=require('../src/backup');
test('safe backup filename blocks path injection',()=>{
  assert.equal(safeFilename('a/b\\c:.json'),'a_b_c_.json');
});
test('backup requires explicit local folder and creates distinct files',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'ta-test-'));
  const service=new BackupService(path.join(dir,'data'));
  try{
    assert.match(service.configure('local',true,24),/مجلد/);
    service.setFolder(dir);
    assert.equal(service.configure('local',true,24),'');
    service.stageSnapshot(JSON.stringify({app:'AlRaedAccountingERP',data:{invoices:[],accounts:[]}}));
    assert.equal(await service.runNow('local'),true);
    const files=fs.readdirSync(dir).filter(x=>x.endsWith('.json'));
    assert.equal(files.length,1);
    assert.ok(service.status().localLast>0);
  }finally{service.dispose();fs.rmSync(dir,{recursive:true,force:true});}
});
