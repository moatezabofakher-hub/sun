const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
const device=fs.readFileSync(path.join(__dirname,'../web/static/desktop-peripherals.js'),'utf8');
const style=fs.readFileSync(path.join(__dirname,'../web/static/windows-modal-guard.css'),'utf8');
const guard=require('../web/static/windows-modal-guard.js');
const button=(text,attrs={})=>({textContent:text,getAttribute:(key)=>attrs[key]??null,querySelector:()=>null});

test('modal overlay never closes on click outside modal boundaries',()=>{
  const overlay=html.match(/<div id="modalContainer"[^>]*>/)?.[0]||'';
  assert.ok(overlay,'app modal container exists');
  assert.doesNotMatch(overlay,/on(?:click|mousedown|pointerdown)=/);
  assert.doesNotMatch(html,/wrapper\.onclick=e=>\{if\(e\.target===wrapper\)wrapper\.remove\(\);\}/);
  assert.doesNotMatch(device,/e\.target\s*===\s*panel\)\s*close\(\)/);
});
test('Escape and desktop Back keep working: cancel a popup first, then navigate backwards',()=>{
  const handle=html.slice(html.indexOf('            handleBackButton() {'),html.indexOf('            popScreen() {'));
  const back=html.slice(html.indexOf('            backFromPopup(box, fallback) {'),html.indexOf('            requestCloseModal() {'));
  const keyboard=html.slice(html.indexOf("document.addEventListener('keydown', (event) => {",html.indexOf('window.onAndroidBackPressed')),html.indexOf('// Capacitor Android integration'));
  assert.match(keyboard,/event\.key === 'Escape'/);
  assert.match(keyboard,/handleSystemBack\(\)/);
  assert.match(handle,/UI\.backFromPopup\(document\.getElementById\('dialogBox'\)/);
  assert.match(handle,/UI\.backFromPopup\(document\.getElementById\('modalBox'\)/);
  assert.match(handle,/this\.popScreen\(\)/);
  assert.match(back,/isCancelAction\(button\)/);
  assert.match(back,/cancel\.click\(\)/);
  assert.match(back,/\.ta-popup-exit-red/);
  assert.match(back,/close\.click\(\)/);
  assert.doesNotMatch(back,/isSaveAction|dlgSaveBtn|confirmExitAction/);
});
test('action detection supports Arabic and English Save/Cancel/Stay',()=>{
  assert.equal(guard.inspect([button('حفظ'),button('إلغاء')]).hasCancel,true);
  assert.equal(guard.inspect([button('Save changes'),button('Cancel')]).hasSave,true);
  assert.equal(guard.inspect([button('البقاء'),button('خروج')]).hasCancel,true);
  assert.equal(guard.inspect([button('تأكيد'),button('إغلاق')]).hasCancel,false);
  assert.equal(guard.isSmallCloseIcon(button('×')),true);
  assert.equal(guard.isSmallCloseIcon(button('إلغاء')),false);
});
test('modal show flow injects an explicit X; confirmation dialogs use own decoration',()=>{
  assert.match(html,/b\.innerHTML = html;\s*TiqanyDesktopPopupGuard\.decorate\(b, \(\) => this\.requestCloseModal\(\)\);/);
  assert.match(html,/decorateDecisionDialog\(\) \{/);
  assert.match(html,/this\.decorateDecisionDialog\(\);\s*c\.classList\.remove\('hidden'\)/);
  assert.match(style,/#modalBox \.ta-popup-exit-red/);
  assert.match(style,/#dialogBox \.ta-popup-exit-red/);
  assert.match(style,/linear-gradient\(155deg,#fb7185/);
  assert.match(style,/box-shadow:0 4px 0 #65131e/);
});
test('existing peripheral close X is styled red and hardware backdrop is inert',()=>{
  assert.match(device,/id="taDeviceClose"/);
  assert.match(style,/#taDevicesPanel \.ta-device-close/);
  assert.doesNotMatch(device,/panel\.addEventListener\('mousedown'/);
});
