const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');
const html=fs.readFileSync('web/index.html','utf8');const preload=fs.readFileSync('src/preload.js','utf8');
test('dashboard report icons removed; new report menu, choice and preview actions exist',()=>{
 const home=html.slice(html.indexOf('renderDashboard(main) {'),html.indexOf('// ==================== 6.2 ITEMS'));
 assert.doesNotMatch(home,/LedgerReports\.openHomePrint/);
 assert.match(html,/LedgerReports\.openPrintChooser\(\)/);
 assert.match(html,/data-report-print-chooser/);
 assert.match(html,/openPreview\('sales_summary'\)/);
 assert.match(html,/openPreview\('debts_summary'\)/);
 assert.match(html,/data-report-preview-actions/);
 assert.match(html,/onclick="LedgerReports\.print\(\)"/);
 assert.match(html,/onclick="LedgerReports\.sharePdf\(\)"/);
 assert.match(preload,/shareReport:.*ta-pdf/);
});
