'use strict';
const { test }=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const { webcrypto }=require('node:crypto');
const cloudSource=fs.readFileSync(path.resolve(__dirname,'../web/static/tiqany-cloud-manager.js'),'utf8');
test('manager registers per-agent credentials and passes the manager lease device ID',async()=>{
 const seen=[];
 const company='company_0123456789abcdef';
 const state={fieldSync:{companyId:company,agents:[{id:'agent_0123456789abcdef',name:'مندوب'}]}};
 let setup;
 const context={crypto:webcrypto,URL,AbortController,setTimeout,clearTimeout,setInterval:()=>1,
   localStorage:{store:{},getItem(k){return this.store[k]},setItem(k,v){this.store[k]=v}},
   document:{readyState:'loading',hidden:false,addEventListener(n,fn){setup=fn},getElementById(id){return id==='taCloudUrl'?{value:'https://relay.example.test'}:null},querySelector(){return null}},
   FieldSync:{data:()=>state.fieldSync,escape:v=>String(v),open:()=>{},catalog:()=>({kind:'provision'}),addAgent:async()=>{},bootAutoReceiver:async()=>{}},
   StorageEngine:{saveState:async()=>{}},UI:{toast:()=>{}},FieldProtocol:{uuid:()=>''.padEnd(32,'f'),b64u:b=>Buffer.from(b).toString('base64url')},
   fetch:async(url,options)=>{seen.push({url,body:JSON.parse(options.body),auth:options.headers.Authorization});return {ok:true,json:async()=>({ok:true})}}};
 context.window=context;context.globalThis=context;
 vm.runInNewContext(cloudSource,context);
 setup();
 // Register without triggering the periodic pump test; enable() will call start().
 context.TiqanyCloudManager.start=()=>{};
 await context.TiqanyCloudManager.enable();
 assert.equal(seen.length,2);
 assert.match(seen[0].url,/\/v1\/register$/);
 assert.equal(seen[0].body.companyId,company);
 assert.match(seen[0].body.deviceId,/^[a-f0-9]{32}$/);
 assert.match(seen[1].url,/\/v1\/manager\/agents$/);
 assert.equal(seen[1].body.deviceId,seen[0].body.deviceId);
 assert.equal(seen[1].body.agents.length,1);
 assert.match(seen[1].body.agents[0].token,/^[A-Za-z0-9_-]{40,}$/);
 assert.notEqual(seen[0].auth,seen[1].body.agents[0].token);
 assert.equal(context.FieldSync.catalog(state.fieldSync.agents[0]).cloud.enabled,true);
});
