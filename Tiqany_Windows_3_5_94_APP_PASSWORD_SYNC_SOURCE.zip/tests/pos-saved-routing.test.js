'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.join(__dirname,'..');
const code=fs.readFileSync(path.join(root,'web/static/windows-pos.js'),'utf8');
const html=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
const original={id:'inv_pos_1',number:31,date:'2026-11-14T10:05',type:'sale',source:'windows-pos',currency:'USD',exchangeRate:14000,accountId:'account_old',warehouseId:'wh_main',paymentMethod:'cash',rows:[{itemId:'p1',itemName:'منتج',unitName:'قطعة',qty:2,price:7,total:14}],subTotal:14,netTotal:14,paidAmount:14,remainingAmount:0};
function setup(){
  const state={settings:{posAccountId:'account_new',posPriceTier:'consumer',selectedWarehouseId:'wh_main'},accounts:[{id:'account_old',type:'customer',name:'قديم'},{id:'account_new',type:'customer',name:'جديد'}],invoices:[structuredClone(original)],items:[],categories:[],warehouses:[{id:'wh_main'}]};
  const nav=[];const ctx={State:state,AppEscape:{text:String},AppNav:{current:()=>({screen:'pos'}),clearDirty(){},enableOperationGuard(){},navigate(...args){nav.push(args)}},InvoiceController:{draft:null,renderForm(_main,params){let x=state.invoices.find(i=>i.id===params.id);this.draft=x?{...structuredClone(x),isEditing:true}:{type:'sale',isEditing:false,rows:[],id:'new_1',accountId:'',currency:'USD',exchangeRate:14000};},async saveInvoice(){const d=this.draft;const i=state.invoices.findIndex(x=>x.id===d.id);if(i>=0)state.invoices[i]={...d};else state.invoices.push({...d});return true;},recalculate(){}},UI:{setHeader(){},toast(){}},window:{},document:{getElementById(){return null}}};
  vm.createContext(ctx);vm.runInContext(code+';globalThis.pos=POSController;',ctx);ctx.pos.paint=()=>{};
  return {state,nav,pos:ctx.pos,controller:ctx.InvoiceController};
}
test('POS records stay normal sales with an explicit persistent source, not every cash sale',()=>{
 const {pos}=setup();assert.equal(pos.isPOS(original),true);
 assert.equal(pos.isPOS({...original,source:undefined}),false);
 assert.equal(pos.isPOS({...original,type:'purchase'}),false);
 assert.equal(pos.isPOS({...original,source:'agent-pos'}),true);
});
test('saved POS opens as a read-only POS with identical historical fields',()=>{
 const {pos,controller}=setup();pos.render({}, {id:original.id,view:true});
 assert.equal(pos.readOnly,true);assert.equal(controller.draft.id,original.id);
 assert.equal(controller.draft.accountId,'account_old');assert.equal(controller.draft.rows[0].price,7);
 assert.equal(pos.add('p1'),false);
});
test('editing POS keeps original account and updates same invoice ID, never creates another',async()=>{
 const {pos,controller,state,nav}=setup();pos.render({}, {id:original.id});
 controller.draft.rows[0].qty=3;
 assert.equal(await pos.save(false),true);
 assert.equal(state.invoices.length,1);
 assert.equal(state.invoices[0].id,original.id);
 assert.equal(state.invoices[0].accountId,'account_old');
 assert.equal(state.invoices[0].rows[0].qty,3);
 assert.equal(nav.at(-1)[0],'invoices_list');
});
test('every entry point routes stored POS to POS view/edit rather than ordinary sale',()=>{
 assert.match(html,/openSavedInvoice\(invoiceId, mode='edit'\)/);
 assert.match(html,/if\(POSController\.isPOS\(inv\)\)return AppNav\.navigate\('pos',\{id:inv.id,view:mode==='view'\}\)/);
 assert.match(html,/نقطة بيع نقدية/);
 assert.match(html,/AppNav\.navigate\('pos',\{id:params.id\},true\)/);
});
