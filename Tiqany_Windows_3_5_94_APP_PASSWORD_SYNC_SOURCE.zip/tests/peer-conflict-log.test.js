'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const merge=require('../web/static/tiqany-peer-merge.js');
const source=fs.readFileSync(path.join(__dirname,'../web/static/tiqany-peer-controller.js'),'utf8');
const inv=(qty)=>({id:'inv-55',number:55,type:'sale',currency:'SYP',accountId:'a',rows:[{itemId:'i',qty}],netTotal:qty*100});
const state=qty=>({settings:{companyName:'مؤسسة',exchangeRate:15000},categories:[],items:[],accounts:[],invoices:[inv(qty)],vouchers:[],warehouses:[],transfers:[],expenses:[]});
function view(desktop,qty,records){
 const State=state(qty),w={TiqanyPeerMerge:merge,confirm:()=>true},listeners=[];let counter=0;
 const profile={activeId:'p1',getRecord:async k=>records.get(k)||null,putBatch:async rows=>{for(const r of rows)records.set(r.id,r);},makeCheckpoint:async()=>{counter++;}};
 const doc={head:{append(){}},createElement(){return {textContent:''};},getElementById(){return null;},addEventListener(){}};
 const ctx={State,console,document:doc,window:w,confirm:()=>true,setTimeout,clearTimeout,setInterval(){return 1;},UI:{toast(){}},ProfileManager:profile,AppNav:{isDirty:false,isModalDirty:false,activeOperationGuard:false,current(){return {screen:'settings'};},renderCurrent(){}},SettingsDraftController:{changed(){return false;}},Views:{renderSettings(){}},StorageEngine:{saveState:async()=>{}}};
 if(desktop){w.WindowsPeerSync={config:async()=>({serverId:'ab'.repeat(16),key:'key',ips:['192.168.1.2'],port:39271,ready:true}),reply(){},};ctx.WindowsPeerSync=w.WindowsPeerSync;w.WindowsDesktop={onPeerRequest(cb){listeners.push(cb);}};}
 else {ctx.AndroidPeerSync={status(){return JSON.stringify({host:'192.168.1.2',port:39271,approved:true});},request(){},approve(){}};w.AndroidPeerSync=ctx.AndroidPeerSync;}
 vm.runInNewContext(source,ctx,{filename:'tiqany-peer-controller.js'});
 return {ctx,State,window:w,peer:w.TiqanyPeerSync,listeners,profile,counter:()=>counter};
}

test('same invoice conflict has both versions, and approval is tied to a specific version',()=>{
 const base=merge.snapshot(state(1)),phone=merge.snapshot(state(2)),desktop=merge.snapshot(state(3));
 const r=merge.merge(base,phone,desktop);assert.equal(r.ok,false);assert.equal(r.details.length,1);assert.equal(r.details[0].phone.netTotal,200);assert.equal(r.details[0].computer.netTotal,300);
 const k=r.details[0];const approved={[k.id]:{side:'phone',signature:k.signature}};
 const res=merge.merge(base,phone,desktop,approved);assert.equal(res.ok,true);assert.equal(res.snapshot.invoices[0].netTotal,200);
 const changed=merge.merge(base,merge.snapshot(state(4)),desktop,approved);assert.equal(changed.ok,false);assert.notEqual(changed.details[0].signature,k.signature);
});

test('review all conflicts before applying; partial decisions must not discard earlier selections',()=>{
 const b=merge.snapshot(state(1)),p=merge.snapshot(state(2)),w=merge.snapshot(state(3));
 b.vouchers=[{id:'v',number:2,amount:10}];p.vouchers=[{id:'v',number:2,amount:20}];w.vouchers=[{id:'v',number:2,amount:30}];
 const first=merge.merge(b,p,w);assert.equal(first.details.length,2);
 const invConflict=first.details.find(x=>x.collection==='invoices');
 const partial=merge.merge(b,p,w,{[invConflict.id]:{side:'computer',signature:invConflict.signature}});
 assert.equal(partial.ok,false);assert.equal(partial.details.length,2);
 const complete=Object.fromEntries(first.details.map(x=>[x.id,{side:'phone',signature:x.signature}]));
 const completeMerge=merge.merge(b,p,w,complete);assert.equal(completeMerge.ok,true);assert.equal(completeMerge.snapshot.vouchers[0].amount,20);
});

test('explicit selection safely resolves deletion-vs-edit, not a new inventory shortage',()=>{
 const b=merge.snapshot(state(1)),p=merge.snapshot(state(1)),w=merge.snapshot(state(3));p.invoices=[];
 const conflict=merge.merge(b,p,w);assert.equal(conflict.ok,false);assert.equal(conflict.details[0].hasPhone,false);
 const d=conflict.details[0];const approved={[d.id]:{signature:d.signature,side:'phone'}};
 assert.equal(merge.merge(b,p,w,approved).snapshot.invoices.length,0);
 const it={id:'i',name:'منتج',openingStockBase:10};
 const p2=merge.snapshot({...state(7),items:[it],warehouses:[{id:'wh_main'}]});
 const w2=merge.snapshot({...state(6),items:[it],warehouses:[{id:'wh_main'}]});w2.invoices[0].id='other';
 const issue=merge.merge(null,p2,w2);assert.equal(issue.ok,false);assert.equal(issue.details[0].kind,'inventory');
});

test('desktop conflict log is saved; desktop approval reaches phone and syncs only after confirmation',async()=>{
 const dstore=new Map(),pstore=new Map(),desk=view(true,3,dstore),phone=view(false,2,pstore);
 const old=merge.snapshot(state(1));pstore.set('peer_mobile_base:p1',{id:'peer_mobile_base:p1',data:{profileId:'p1',serverId:'ab'.repeat(16),serverProfileId:'p1',snapshot:old}});
 desk.window.WindowsPeerSync.reply=(requestId,obj)=>{queueMicrotask(()=>{phone.window.__tiqanyPeerReply(JSON.stringify(obj));});};
 phone.ctx.AndroidPeerSync.request=raw=>{const data=JSON.parse(raw);queueMicrotask(()=>desk.peer.handleRequest({requestId:++desk.nextID||String(Date.now()),data}));};
 await desk.window.onload();await phone.window.onload();
 await phone.peer.sync(false);
 assert.equal(phone.State.invoices[0].netTotal,200);assert.equal(desk.State.invoices[0].netTotal,300);
 assert.equal(phone.peer.conflictLog.details.length,1);assert.equal(desk.peer.conflictLog.details.length,1);
 assert.equal(phone.peer.conflictLog.confirmed,false);
 await desk.peer.chooseConflict(0,'computer');
 assert.equal(desk.peer.conflictLog.confirmed,false);
 await desk.peer.confirmConflicts();
 assert.equal(desk.peer.conflictLog.confirmed,true);
 await phone.peer.sync(false);
 assert.equal(phone.State.invoices[0].netTotal,300);assert.equal(desk.State.invoices[0].netTotal,300);
 assert.equal(phone.peer.conflictLog,null);assert.equal(desk.peer.conflictLog,null);
 assert.equal((await phone.peer.base()).snapshot.invoices[0].netTotal,300);
 assert.ok(phone.counter()>=1);
});

test('conflict icon reveals exact phone and desktop versions and selection controls',async()=>{
 const record=new Map(),a=view(true,3,record),base=merge.snapshot(state(1)),phone=merge.snapshot(state(2)),desktop=merge.snapshot(state(3));
 const issue=merge.merge(base,phone,desktop);
 const elements={
  'ta-peer-conflict-button':{innerHTML:'',classList:{toggle(){}}},
  'ta-peer-conflict-panel':{innerHTML:'',hidden:true,scrollIntoView(){}}
 };
 a.ctx.document.getElementById=id=>elements[id]||null;
 await a.peer.recordConflicts(issue.details,{serverId:'ab'.repeat(16),phoneProfileId:'p1'});
 assert.match(elements['ta-peer-conflict-button'].innerHTML,/سجل التعارض \(1\)/);
 a.peer.openConflictLog();const html=elements['ta-peer-conflict-panel'].innerHTML;
 assert.match(html,/نسخة الموبايل الرئيسي/);assert.match(html,/نسخة الكمبيوتر/);
 assert.match(html,/netTotal: 200/);assert.match(html,/netTotal: 300/);
 assert.match(html,/اعتماد الموبايل/);assert.match(html,/اعتماد الكمبيوتر/);
 assert.match(html,/اعتماد الحلول على الكمبيوتر/);
 await a.peer.chooseConflict(0,'phone');
 assert.match(elements['ta-peer-conflict-panel'].innerHTML,/✓ اعتماد الموبايل/);
});
