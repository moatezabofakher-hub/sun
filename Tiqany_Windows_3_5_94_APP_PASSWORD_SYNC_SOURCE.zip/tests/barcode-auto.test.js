'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const scannerJS=fs.readFileSync(path.join(root,'web/static/desktop-peripherals.js'),'utf8');
const posJS=fs.readFileSync(path.join(root,'web/static/windows-pos.js'),'utf8');
const html=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
function scannerEnv(){
 let now=1000,homeCalls=[],invoiceCodes=[],posCodes=[],messages=[],focused=null;
 const listeners=new Map();
 const state={settings:{posScanFromHome:false},items:[{id:'a',barcode:'10001'}]};
 const current={screen:'dashboard'};
 const document={readyState:'loading',getElementById(){return null;},
  addEventListener(type,fn){const list=listeners.get(type)||[];list.push(fn);listeners.set(type,list);}};
 const window={WindowsDesktop:{onDevicesOpen(){},onScannerOpen(){},onDeviceConfig(){},onPrinterStatus(){}},
  WindowsDevices:{settings:async()=>({scanner:{autoCapture:true,minLength:4,maxGapMs:110,suffix:'both'}})}};
 const ctx={window,document,performance:{now:()=>now},State:state,
  AppNav:{current:()=>current},
  InvoiceController:{draft:{rows:[]},addItemByBarcode(code){invoiceCodes.push(code);}},
  POSController:{openFromBarcode(code){homeCalls.push(code);return true;},addBarcode(code){posCodes.push(code);return true;}},
  UI:{toast:(message)=>messages.push(message)},
  console,Event:class Event{constructor(type,props){this.type=type;this.bubbles=props?.bubbles;}}};
 vm.createContext(ctx);vm.runInContext(scannerJS,ctx);for(const f of listeners.get('DOMContentLoaded')||[])f();
 function typeBarcode(code,{gap=17,target=null}={}){
   let prevented=0,stopped=0;
   const node=target||{isContentEditable:false,matches(){return false;},closest(){return null;}};
   for(const char of code+'\n'){
     const key=char==='\n'?'Enter':char;
     const e={key,target:node,ctrlKey:false,metaKey:false,altKey:false,isComposing:false,repeat:false,
      preventDefault(){prevented++;},stopPropagation(){stopped++;}};
     for(const f of listeners.get('keydown')||[])f(e);
     if(key!=='Enter'&&node.type==='search')node.value+=key;
     now+=gap;
   }
   return {prevented,stopped};
 }
 return {ctx,state,current,homeCalls,invoiceCodes,posCodes,messages,typeBarcode};
}
test('home-scan option defaults to off and is included in invoice settings only',()=>{
 assert.match(html,/posScanFromHome: false/);
 assert.match(html,/id="posScanFromHomeSetting"/);
 assert.match(html,/onchange="POSController.saveSettings\(\)"/);
});
test('HID barcode opens POS only from dashboard when opted in and barcode is known',async()=>{
 const x=scannerEnv();await new Promise(r=>setImmediate(r));
 x.typeBarcode('10001');assert.deepEqual(x.homeCalls,[]);
 x.state.settings.posScanFromHome=true;
 const result=x.typeBarcode('10001');assert.equal(result.prevented,1);
 assert.deepEqual(x.homeCalls,['10001']);
 x.typeBarcode('99999');assert.equal(x.homeCalls.length,1);
 x.current.screen='accounts';x.typeBarcode('10001');assert.equal(x.homeCalls.length,1);
});
test('scanner adds repeated items to open invoice and POS without barcode button',async()=>{
 const x=scannerEnv();await new Promise(r=>setImmediate(r));
 x.current.screen='invoice_form';x.typeBarcode('10001');x.typeBarcode('10001');
 assert.deepEqual(x.invoiceCodes,['10001','10001']);
 x.current.screen='pos';x.typeBarcode('10001');assert.deepEqual(x.posCodes,['10001']);
});
test('focused search input is restored before routing a recognized scanner burst',async()=>{
 const x=scannerEnv();await new Promise(r=>setImmediate(r));
 x.current.screen='pos';
 let inputEvents=0;
 const field={id:'posSearch',type:'search',value:'قبل المسح',isConnected:true,selectionStart:9,selectionEnd:9,
    matches:selector=>selector.startsWith('input:not'),closest:()=>null,isContentEditable:false,dispatchEvent(){inputEvents++;},setSelectionRange(){}};
 const xresult=x.typeBarcode('10001',{target:field});
 assert.equal(xresult.prevented,1);assert.equal(field.value,'قبل المسح');
 assert.equal(inputEvents,1);assert.deepEqual(x.posCodes,['10001']);
});
test('ordinary keyboard typing is not mistaken for a scanner',async()=>{
 const x=scannerEnv();await new Promise(r=>setImmediate(r));
 x.current.screen='invoice_form';x.typeBarcode('10001',{gap:250});
 assert.deepEqual(x.invoiceCodes,[]);
});
test('POS opens a brand-new draft only when home option enabled and code exists',()=>{
 const state={settings:{posScanFromHome:true,posPriceTier:'account'},items:[{id:'a',barcode:'10001'}],accounts:[]};
 const draft={rows:[]};let navigations=[];let screen='dashboard';
 const ctx={State:state,InvoiceController:{draft},AppEscape:{text:x=>x},UI:{toast(){}},
  AppNav:{get isDirty(){return false;},get isModalDirty(){return false;},get activeOperationGuard(){return false;},
   current:()=>({screen}),navigate(target,params){navigations.push({target,params});screen=target;draft.rows=[{itemId:'a',qty:1}];}},
  document:{getElementById(){return null;}}};
 vm.createContext(ctx);vm.runInContext(posJS+'\n;globalThis.__POS=POSController;',ctx);
 const pos=ctx.__POS;
 assert.equal(pos.openFromBarcode('10001'),true);assert.equal(navigations.length,1);
 assert.equal(navigations[0].params.startBarcode,'10001');
 assert.equal(pos.openFromBarcode('10001'),false);assert.equal(navigations.length,1);
 screen='dashboard';assert.equal(pos.openFromBarcode('does-not-exist'),false);assert.equal(navigations.length,1);
 state.settings.posScanFromHome=false;assert.equal(pos.openFromBarcode('10001'),false);
});
