const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const main=fs.readFileSync(path.join(__dirname,'..','src','main.js'),'utf8');
test('starts maximized within OS desktop work area, rather than hiding Windows taskbar',()=>{
  assert.match(main,/show:false,fullscreen:false/);
  assert.match(main,/mainWindow\.show\(\);mainWindow\.maximize\(\)/);
  assert.doesNotMatch(main,/setFullScreen\(/);
});
test('F11 restores or maximizes within work area, not full screen',()=>{
  assert.match(main,/تكبير \/ استعادة النافذة \(F11\)/);
  assert.match(main,/mainWindow\.isMaximized\(\)/);
  assert.match(main,/mainWindow\.unmaximize\(\)/);
});
