const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const pkg = require('../package.json');
const main = fs.readFileSync(path.join(__dirname,'../src/main.js'),'utf8');

test('raw print helper is copied out of ASAR as a real Windows resource',()=>{
  assert(pkg.build.extraResources.some(r=>r.from==='scripts/print-raw.ps1'&&r.to==='scripts/print-raw.ps1'));
  assert(fs.existsSync(path.join(__dirname,'../scripts/print-raw.ps1')));
});

test('installed Windows version resolves print helper from process.resourcesPath',()=>{
  assert.match(main,/app\.isPackaged[\s\S]*?process\.resourcesPath[\s\S]*?scripts[\s\S]*?print-raw\.ps1/);
  assert.match(main,/'-File',rawPrintScript/);
  const simulated = path.win32.join('C:\\Program Files\\Tiqany Acc Manager\\resources','scripts','print-raw.ps1');
  assert.equal(simulated,'C:\\Program Files\\Tiqany Acc Manager\\resources\\scripts\\print-raw.ps1');
  assert(!simulated.includes('app.asar'));
});

test('absence of raw printing helper produces actionable error',()=>{
  assert.match(main,/fs\.existsSync\(rawPrintScript\)/);
  assert.match(main,/ملف تشغيل الطابعة الحرارية غير موجود/);
});
