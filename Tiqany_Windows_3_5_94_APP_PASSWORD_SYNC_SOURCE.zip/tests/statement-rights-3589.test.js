'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../web/static');
function script(name,context={}){const ctx=vm.createContext({...context});vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),ctx,{filename:name});return ctx;}
const S=script('account-statement-period-3589.js').AccountStatementPeriod;
function row(date,currency,debit,credit,rate,ref='F'){return {date,currency,debit,credit,rate,ref,desc:'عملية اختبار'};}
test('date range carries all previous transactions as opening, separately for both currencies',()=>{
  const data=S.build([
    row('2026-01-01','USD','400.11','0','12000'),
    row('2026-01-02','SYP','2000','0','12000'),
    row('2026-02-01','USD','0','130.06','12500'),
    row('2026-02-02','SYP','0','600','12500'),
    row('2026-03-01','USD','888.00','0','16000')], '2026-02-01','2026-02-28');
  assert.equal(data.opening.USD,'400.11');assert.equal(data.opening.SYP,'2,000');
  assert.equal(data.ending.USD,'270.05');assert.equal(data.ending.SYP,'1,400');
  assert.equal(data.rows.length,2);assert.equal(data.rows[0].rate,'12500');
  assert.equal(data.rows[0].balanceExact,'270.05');assert.equal(data.rows[1].balanceExact,'1,400');
});
test('precise fixed-point arithmetic resists float drift and uses eight places',()=>{
 const data=S.build([row('2026-11-01','USD','0.1','0',1),row('2026-11-01','USD','0.2','0',1),row('2026-11-02','USD','0.00000001','0',1)]);
 assert.equal(data.ending.USD,'0.30000001');assert.equal(data.rows[2].balanceExact,'0.30000001');
 assert.equal(S.money('2000.50'), '2,000.5');
 assert.equal(S.money(0.1+0.2),'0.3');
 assert.throws(()=>S.parse('0.000000001'),/8/);
});
test('opening may be negative and rows stop at chosen inclusive ending day',()=>{
 const data=S.build([row('2025-12-30','SYP','0','30',1),row('2026-01-01T23:59:59','SYP','10','0',1),row('2026-01-02','SYP','900','0',1)],'2026-01-01','2026-01-01');
 assert.equal(data.opening.SYP,'-30');assert.equal(data.ending.SYP,'-20');assert.equal(data.rows.length,1);
 assert.throws(()=>S.build([], '2026-02-02','2026-02-01'),/تاريخ/);
});
test('PDF statement payload includes company identifiers, FX for every row and opening totals',()=>{
 const local=script('account-statement-period-3589.js',{State:{settings:{companyName:'شركة التجربة',companyPhone:'111',exchangeRate:500,companyAddress:'السويداء',companyLogo:'data:image/png;base64,abc'}}}).AccountStatementPeriod;
 const p=local.payload({name:'أحمد'},[row('2026-01-01','USD',100,0,600),row('2026-02-11','USD',0,30,650)],'2026-02-01','2026-02-28');
 assert.equal(p.companyName,'شركة التجربة');assert.equal(p.opening.USD,'100');assert.equal(p.ending.USD,'70');
 assert.equal(p.rows.length,1);assert.equal(p.rows[0].rate,'650');assert.equal(p.companyLogo,'data:image/png;base64,abc');
});
test('desktop PDF HTML statement properly escapes customer data and contains green/red columns',()=>{
 const {statementHTML}=require('../src/pdf');const h=statementHTML({companyName:'My <Company>',accountName:'Test & Name',rows:[{date:'2026-01-01',reference:'F1',detail:'sale',rate:'15000',currency:'USD',debit:'100',credit:'0',balance:'100'}],opening:{USD:'0',SYP:'0'},ending:{USD:'100',SYP:'0'}});
 assert.match(h,/My &lt;Company&gt;/);assert.match(h,/Test &amp; Name/);assert.match(h,/pos num/);assert.match(h,/neg num/);
});
test('field protocol accepts item creation followed by sale in same authenticated batch',()=>{
 const p=require('../web/static/field-protocol');
 const item={id:'itm_field_'+'a'.repeat(32),name:'مادة جديدة',unitName:'عبوة',currency:'USD',salePrice:1.25,costPrice:0.7};
 const base={companyId:'company_test',agentId:'agent_test',warehouseId:'wh_test',currency:'USD',exchangeRate:50000,date:'2026-11-15T10:00:00Z'};
 const create={...base,id:'op_'+'a'.repeat(32),kind:'item_create',item};
 const sale={...base,id:'op_'+'b'.repeat(32),kind:'sale',accountId:'',paidAmount:1.25,netTotal:1.25,rows:[{itemId:item.id,unitName:'عبوة',unitFactor:1,qty:1,price:1.25,total:1.25}]};
 const [newItem,newSale]=p.validateOps([create,sale],base.agentId,base.companyId,base.warehouseId,[],[]);
 assert.equal(newItem.item.units[0].salePrice,1.25);assert.equal(newItem.item.openingStockBase,0);assert.equal(newSale.netTotal,1.25);
 const docs=p.toLedgerDocuments([newItem,newSale],{id:base.agentId,name:'Staff',warehouseId:base.warehouseId},0,0);
 assert.equal(docs.items.length,1);assert.equal(docs.invoices.length,1);
 assert.throws(()=>p.validateOps([create,create],base.agentId,base.companyId,base.warehouseId,[],[]),/مكرر/);
});
test('manager permission check rejects unauthorized creation/edit/delete from employee',()=>{
 const ctx=script('agent-permissions-3589.js',{document:{querySelector(){return null}}});const p=ctx.TiqanyAgentPermissions;
 const staff={permissions:{createItems:false,createAccounts:false,editOperations:false,deleteOperations:false}};
 for(const kind of ['item_create','customer_create','document_edit','document_delete']){
   assert.throws(()=>p.assertOperations([{kind}],staff),/صلاحية/);
 }
 staff.permissions={...staff.permissions,createItems:true};assert.equal(p.assertOperations([{kind:'item_create'}],staff),true);
});
