'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {normalizeDeviceConfig, loadDeviceConfig, writeDeviceConfig, makeThermalTestBytes} = require('../src/device-config');
test('printer and barcode scanner options are normalized defensively', () => {
  const x=normalizeDeviceConfig({printerName:'USB Receipt\u0000\n',printMode:'system',paperMm:58,
    scanner:{autoCapture:false,minLength:1,maxGapMs:10000,suffix:'custom'}});
  assert.equal(x.printerName,'USB Receipt');
  assert.equal(x.printMode,'system');
  assert.equal(x.paperMm,58);
  assert.equal(x.scanner.minLength,3);
  assert.equal(x.scanner.maxGapMs,500);
  assert.equal(x.scanner.suffix,'both');
});
test('printer & scanner settings survive restart', () => {
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'tiqany-devices-'));
  try {
    const p=path.join(temp,'devices.json');
    assert.equal(loadDeviceConfig(p).printMode,'thermal');
    writeDeviceConfig(p,{printerName:'XP-80 USB',paperMm:80,scanner:{autoCapture:false}});
    assert.equal(loadDeviceConfig(p).printerName,'XP-80 USB');
    assert.equal(loadDeviceConfig(p).scanner.autoCapture,false);
  } finally {fs.rmSync(temp,{recursive:true,force:true});}
});
test('ESC/POS device print check contains printer reset, paper size and cut command', () => {
  const x=makeThermalTestBytes(58);
  assert.ok(x.includes(Buffer.from('PAPER: 58 mm')));
  assert.equal(x[0],0x1b); assert.equal(x.at(-4),0x1d);
});
