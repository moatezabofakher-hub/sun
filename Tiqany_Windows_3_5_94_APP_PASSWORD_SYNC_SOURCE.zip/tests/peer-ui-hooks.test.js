'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
const code=fs.readFileSync(path.join(__dirname,'../web/static/tiqany-peer-controller.js'),'utf8');
const merge=require('../web/static/tiqany-peer-merge.js');
function setup(desktop){
 const main={markup:'',insertAdjacentHTML(position,html){this.markup+=html;}};
 const State={settings:{companyName:'مؤسسة',language:'ar'},categories:[],items:[],accounts:[],invoices:[],vouchers:[],warehouses:[],transfers:[],expenses:[]};
 const ctx={console,setTimeout,clearTimeout,setInterval(){return 1;},confirm:()=>true,
  document:{head:{append(){}},createElement(){return {textContent:''};},getElementById:()=>null,addEventListener(){}},
  State,Views:{renderSettings(m){m.innerHTML='<p>old</p>'; }},
  UI:{toast(){}},AppNav:{current(){return {screen:'settings'};},isDirty:false,isModalDirty:false},
  ProfileManager:{activeId:'business_1',getRecord:async()=>null,putBatch:async()=>{},makeCheckpoint:async()=>{}},
  StorageEngine:{saveState:async()=>{}},
  SettingsDraftController:{changed:()=>false},
  window:{TiqanyPeerMerge:merge,onload:async()=>{}}
 };
 if(desktop){ctx.window.WindowsPeerSync={config:async()=>({serverId:'serverid',key:'abc',ips:['192.168.1.5'],port:39271,ready:true}),reply(){}};ctx.window.WindowsDesktop={onPeerRequest(){}};ctx.WindowsPeerSync=ctx.window.WindowsPeerSync;}
 else {ctx.AndroidPeerSync={status:()=>'{"host":"192.168.1.5","port":39271,"approved":false}',configure:()=> 'saved',request(){},approve(){}};ctx.window.AndroidPeerSync=ctx.AndroidPeerSync;}
 vm.runInNewContext(code,ctx);
 return {ctx,main};
}
test('new local synchronization settings screen is installed in Windows manager',async()=>{
 const {ctx,main}=setup(true);await ctx.window.onload();ctx.Views.renderSettings(main);
 assert.match(main.markup,/المزامنة المحلية/);assert.match(main.markup,/config\(\)/);
 assert.equal(typeof ctx.window.TiqanyPeerSync.handleRequest,'function');
});
test('new local synchronization settings screen is installed in Android main',async()=>{
 const {ctx,main}=setup(false);await ctx.window.onload();ctx.Views.renderSettings(main);
 assert.match(main.markup,/مزامنة الآن/);assert.match(main.markup,/TiqanyPeerSync\.sync\(\)/);
 assert.equal(typeof ctx.window.__tiqanyPeerReply,'function');
});
test('initial currency settings use desktop preference with explicit first-link confirmation',()=>{
 const left=merge.snapshot({settings:{companyName:'مؤسسة',exchangeRate:20000}});
 const right=merge.snapshot({settings:{companyName:'مؤسسة',exchangeRate:15000}});
 const data=merge.merge(null,left,right);
 assert.equal(data.ok,true);assert.equal(data.snapshot.sharedSettings.exchangeRate,15000);
 assert.equal(data.stats.settingsFromDesktop,1);
});
