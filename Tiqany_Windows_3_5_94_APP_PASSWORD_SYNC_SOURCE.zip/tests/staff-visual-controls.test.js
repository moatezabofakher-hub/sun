'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const contents=p=>fs.readFileSync(path.join(root,p),'utf8');
test('agent can be revoked when online or offline, guarded by existing PIN and direct settings when absent',()=>{
 const code=contents('web/static/field-main.js');
 assert.match(code,/removeAgent\(id\)\{/);
 assert.match(code,/ProtectionController\.goToPinSetup\(\)/);
 assert.match(code,/requirePinForDestructiveAction\(/);
 assert.match(code,/removeAgentAuthorized\(id,pin\)/);
 assert.match(code,/verifyPin\(pin\)/);
 assert.match(code,/a\.archived=true;a\.disabled=true/);
 assert.match(code,/agent=config\.agents\.find\(a=>a\.id===packet\.agentId&&!a\.disabled&&!a\.archived\)/);
 assert.doesNotMatch(code.slice(code.indexOf('removeAgent(id){'),code.indexOf('async restoreAgent(id){')),/lanListening\s*===\s*false|agent\.online\s*===\s*false/);
});
test('staff connection badge counts recent authenticated syncs only',()=>{
 const code=contents('web/static/field-main.js');
 assert.match(code,/presenceTTL:\s*40000/);
 assert.match(code,/this\.markConnectedAgent\(agent\.id\)/);
 assert.match(code,/!a\.archived&&!a\.disabled/);
 assert.match(contents('web/index.html'),/id="salesStaffConnectedCount"/);
});
test('new desktop navigation is after header and before main content',()=>{
 const html=contents('web/index.html');
 const header=html.indexOf('id="topAppBar"'),nav=html.indexOf('<nav class="ta-bottom-nav'),main=html.indexOf('id="mainContent"');
 assert.ok(header>0 && nav>header && main>nav);
 assert.ok(html.indexOf('data-pos-prominent="true"') < html.indexOf('onclick="AppNav.navigate(\'sale\')"') || html.includes('data-pos-prominent="true"'));
});
test('old POS banner removed while scanner, tier and currency display remain',()=>{
 const code=contents('web/static/windows-pos.js');
 assert.doesNotMatch(code,/<section class="pos-banner">/);
 assert.match(code,/POSController\.openBarcodeScanner\(\)/);
 assert.match(code,/ل\.س/);
 assert.match(contents('web/static/tiqany-3d-ui.css'),/ta-invoice-currency-choice/);
 assert.match(contents('src/pdf.js'),/function displayCurrency\(c\)/);
});
test('all icon class names have an SVG in the bundled local library or an alias',()=>{
 const icons=contents('web/static/icons.js');
 const direct=new Set([...icons.matchAll(/["'](fa-[\w-]+)["']\s*:/g)].map(m=>m[1]));
 const aliases=[...icons.matchAll(/"(fa-[\w-]+)":\s*"(fa-[\w-]+)"/g)];
 const aliasNames=new Set(aliases.map(m=>m[1]));
 for(const alias of aliases)assert.ok(direct.has(alias[2]),`missing alias target ${alias[2]}`);
 assert.match(icons,/ICONS\["fa-qrcode"\]\s*=/);
 const html=contents('web/index.html');
 const referenced=new Set([...html.matchAll(/\bfa-[\w-]+\b/g)].map(m=>m[0]));
 for(const name of referenced){if(!['fa-spin','fa-solid'].includes(name))assert.ok(direct.has(name)||aliasNames.has(name),`missing icon ${name}`)}
});
