'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const net=require('node:net');
const M=require('../web/static/tiqany-peer-merge.js');const {PeerLanServer,encode,decode,PORT}=require('../src/peer-lan-server.js');
const state=(invoice=[],item=[],extra={})=>({settings:{companyName:'مؤسسة',exchangeRate:15000},invoices:invoice,items:item,warehouses:[{id:'wh_main',name:'المستودع الرئيسي'}],...extra});
const inv=(id,number,qty=1)=>({id,number,type:'sale',accountId:'a',currency:'SYP',rows:[{itemId:'it',qty}],netTotal:qty*10});
test('duplicate invoice visible number: both invoices survive, one gets next number',()=>{
 const L=M.snapshot(state([inv('phone',125)]));const R=M.snapshot(state([inv('computer',125)]));
 const result=M.merge(null,L,R);assert.equal(result.ok,true);assert.equal(result.snapshot.invoices.length,2);
 assert.equal(result.snapshot.invoices.find(i=>i.id==='computer').number,125);
 assert.equal(result.snapshot.invoices.find(i=>i.id==='phone').number,126);
 assert.equal(result.snapshot.invoices.find(i=>i.id==='phone').originalNumber,125);
 assert.equal(result.snapshot.invoices.reduce((a,x)=>a+x.netTotal,0),20);
 const next=M.merge(result.snapshot,result.snapshot,result.snapshot);assert.equal(next.ok,true);
 assert.equal(next.stats.renumbered,0);
});
test('independent offline changes to different invoices merge safely',()=>{
 const base=M.snapshot(state([inv('existing',1)]));const phone=M.snapshot(state([inv('existing',1),inv('newPhone',2)]));const desk=M.snapshot(state([inv('existing',1),inv('newDesk',3)]));
 const result=M.merge(base,phone,desk);assert.equal(result.ok,true);assert.equal(result.snapshot.invoices.length,3);
});
test('same invoice edited differently never silently overwrites',()=>{
 const base=M.snapshot(state([inv('i1',100,1)]));const a=M.snapshot(state([inv('i1',100,2)]));const b=M.snapshot(state([inv('i1',100,3)]));
 const result=M.merge(base,a,b);assert.equal(result.ok,false);assert.match(result.conflicts.join(' '),/invoices/);
});
test('deletion on phone propagates if computer has not modified the record',()=>{
 const base=M.snapshot(state([inv('i1',100,1)]));const a=M.snapshot(state());const b=M.snapshot(state([inv('i1',100,1)]));
 const result=M.merge(base,a,b);assert.equal(result.ok,true);assert.deepEqual(result.snapshot.invoices,[]);
});
test('deletion vs remote edit raises conflict',()=>{
 const base=M.snapshot(state([inv('i1',100,1)]));const a=M.snapshot(state());const b=M.snapshot(state([inv('i1',100,2)]));
 const result=M.merge(base,a,b);assert.equal(result.ok,false);
});
test('duplicate stable record IDs with inconsistent fields on first sync abort',()=>{
 const a=M.snapshot(state([inv('i1',100,1)]));const b=M.snapshot(state([inv('i1',100,2)]));
 const result=M.merge(null,a,b);assert.equal(result.ok,false);
});
test('security and activation do not cross devices',()=>{
 const a=M.snapshot(state([],[],{license:{activationCode:'SECRET'},settings:{companyName:'مؤسسة',appProtection:{pinHash:'SENSITIVE'}}}));
 assert.equal(a.license,undefined);assert.equal(a.sharedSettings.appProtection,undefined);
});
test('AES-256-GCM peer packets round-trip; wrong key or tampering rejected',()=>{
 const key=require('node:crypto').randomBytes(32),other=require('node:crypto').randomBytes(32);
 const pack=encode(key,{protocol:'TIQANY-PEER-1',action:'fetch'});
 assert.equal(decode(key,pack.subarray(4)).action,'fetch');assert.throws(()=>decode(other,pack.subarray(4)));
 const msg=JSON.parse(pack.subarray(4).toString());msg.data=msg.data.slice(0,-2)+'AA';assert.throws(()=>decode(key,Buffer.from(JSON.stringify(msg))));
});
test('server responses require a correct encrypted packet and are isolated from the field agent server',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tiqany-peer-test-'));
 const server=new PeerLanServer({userData:dir,onRequest:({requestId,data})=>server.reply(requestId,{ok:true,action:data.action})});
 try{
   await new Promise((resolve,reject)=>{server.start();const check=()=>server.ready?resolve():setTimeout(check,20);setTimeout(()=>{if(!server.ready)reject(new Error('listener failed'));},2000);check();});
   const config=server.config();assert.equal(config.port,PORT);assert.equal(config.key.length,43);
   const reply=await new Promise((resolve,reject)=>{
     const socket=net.createConnection({host:'127.0.0.1',port:PORT});let buff=Buffer.alloc(0),size=-1;
     socket.on('connect',()=>socket.write(encode(Buffer.from(config.key,'base64url'),{protocol:'TIQANY-PEER-1',action:'fetch'})));
     socket.on('data',c=>{buff=Buffer.concat([buff,c]);if(buff.length>=4&&size<0)size=buff.readUInt32BE(0);if(size>=0&&buff.length===size+4){resolve(decode(Buffer.from(config.key,'base64url'),buff.subarray(4)));socket.end();}});
     socket.on('error',reject);
   });assert.deepEqual(reply,{ok:true,action:'fetch'});
 }finally{server.stop();fs.rmSync(dir,{recursive:true,force:true});}
});
test('simultaneous offline sales cannot silently oversell the same stock',()=>{
 const item={id:'it',name:'Dish soap',openingStockBase:10,units:[{factor:1}]};
 const phone=M.snapshot(state([inv('phone',125,7)],[item]));
 const win=M.snapshot(state([inv('desktop',126,6)],[item]));
 const merged=M.merge(null,phone,win);assert.equal(merged.ok,false);assert.match(merged.conflicts.join(' '),/inventory/);
});
