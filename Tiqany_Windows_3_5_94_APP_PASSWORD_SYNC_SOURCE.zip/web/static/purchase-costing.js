/* Tiqany Acc Windows v3.5.55 — latest-purchase landed unit cost.
 * No changes to sales price tiers, inventory quantities, ledger or historical invoices.
 * Calculates price of the most recent dated purchase for each item, including
 * per-line discount/addition, distributed invoice discount/addition and conversion
 * using the invoice's own persisted currency and exchange rate.
 */
(function(root, factory){
  const api=factory();
  if(typeof module==='object' && module.exports)module.exports=api;
  if(root)root.PurchaseCosting=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const finite=x=>Number.isFinite(Number(x))?Number(x):0;
  const nonnegative=x=>Math.max(0,finite(x));
  const roundCost=value=>Math.round((Number(value)+Number.EPSILON)*1e8)/1e8;
  const currency=code=>String(code||'USD').toUpperCase();
  const baseQuantity=row=>{
    const factor=finite(row.unitFactor)>0?finite(row.unitFactor):1;
    return finite(row.qty)/factor;
  };
  function validInvoice(inv){
    if(!inv || inv.type!=='purchase')return null;
    const rows=Array.isArray(inv.rows)?inv.rows:[];
    if(!rows.length)return 'فاتورة الشراء بلا مواد';
    for(const row of rows){
      const qty=finite(row.qty),price=finite(row.price),discount=finite(row.discount),addition=finite(row.purchaseAddAmount);
      if(!row.itemId || !(qty>0) || !Number.isFinite(Number(row.qty)) || !Number.isFinite(Number(row.price)) || price<0)return 'تأكد من وجود مادة وكمية وسعر شراء غير سالب لكل سطر';
      if(discount<0 || !Number.isFinite(Number(row.discount??0)) || discount>qty*price+1e-5)return 'حسم المادة يجب أن يكون بين صفر وقيمتها قبل الحسم';
      if(addition<0 || !Number.isFinite(Number(row.purchaseAddAmount??0)))return 'إضافة المادة يجب أن تكون قيمة غير سالبة';
    }
    const gross=rows.reduce((sum,row)=>sum+Math.max(0,finite(row.qty)*finite(row.price)-finite(row.discount))+nonnegative(row.purchaseAddAmount),0);
    const discount=finite(inv.discountAmount),added=finite(inv.taxAmount);
    if(discount<0 || !Number.isFinite(Number(inv.discountAmount??0)) || discount>gross+1e-5)return 'الحسم العام على فاتورة الشراء أكبر من قيمة الأصناف أو سالب';
    if(added<0 || !Number.isFinite(Number(inv.taxAmount??0)))return 'الإضافات على فاتورة الشراء يجب ألا تكون سالبة';
    return null;
  }
  function rowValue(row){
    // Prefer persisted invoice row total because the invoice uses currency-specific
    // rounding for its own subTotal/netTotal (especially SYP).
    const stored=Number(row.total);
    if(Number.isFinite(stored) && stored>=0)return stored;
    return Math.max(0,finite(row.qty)*finite(row.price)-finite(row.discount)+nonnegative(row.purchaseAddAmount));
  }
  function invoiceAllocations(inv){
    const rows=(inv && Array.isArray(inv.rows))?inv.rows:[];
    const rowsWithQuantity=rows.filter(row=>row.itemId && baseQuantity(row)>0);
    if(!rowsWithQuantity.length)return [];
    const baseValues=rowsWithQuantity.map(row=>nonnegative(rowValue(row)));
    const weights=baseValues.slice();
    let sum=weights.reduce((a,b)=>a+b,0);
    if(sum===0){for(let i=0;i<weights.length;i++)weights[i]=baseQuantity(rowsWithQuantity[i]);sum=weights.reduce((a,b)=>a+b,0);}
    if(!(sum>0))return [];
    const discount=nonnegative(inv.discountAmount),addition=nonnegative(inv.taxAmount);
    // Invoice amount changes are proportional to line value; no premature
    // 2-decimal/USD rounding before allocating to individual units.
    return rowsWithQuantity.map((row,i)=>({
      itemId:String(row.itemId),invoiceId:String(inv.id||''),rowId:String(row.rowId||''),
      quantityBase:baseQuantity(row),
      invoiceCurrency:currency(inv.currency),
      effectiveTotal:Math.max(0,baseValues[i] - discount*weights[i]/sum + addition*weights[i]/sum),
      discountAllocated:discount*weights[i]/sum,
      additionAllocated:addition*weights[i]/sum
    }));
  }
  function convertPrecise(value,from,to,rate){
    if(from===to)return Number(value);
    if(!(Number.isFinite(Number(rate)) && Number(rate)>0))return NaN;
    if(from==='USD'&&to==='SYP')return Number(value)*Number(rate);
    if(from==='SYP'&&to==='USD')return Number(value)/Number(rate);
    return NaN; // Other currencies are not implemented in the dual-currency ledger.
  }
  function recentPurchases(invoices,items){
    const targets=new Map((items||[]).filter(x=>x&&x.id&&!x.isBundle).map(item=>[String(item.id),item]));
    const latest=new Map();
    (invoices||[]).forEach((inv,index)=>{
      if(!inv||inv.type!=='purchase'||validInvoice(inv))return;
      const date=String(inv.date||'');
      const number=finite(inv.number);
      const grouped=new Map();
      for(const part of invoiceAllocations(inv)){
        const item=targets.get(part.itemId);if(!item)continue;
        const lineAmount=convertPrecise(part.effectiveTotal,part.invoiceCurrency,currency(item.currency),inv.exchangeRate);
        if(!Number.isFinite(lineAmount))continue;
        const previous=grouped.get(part.itemId)||{baseQty:0,amount:0,allocatedDiscount:0,allocatedAddition:0};
        previous.baseQty+=part.quantityBase;
        previous.amount+=lineAmount;
        previous.allocatedDiscount+=part.discountAllocated;
        previous.allocatedAddition+=part.additionAllocated;
        grouped.set(part.itemId,previous);
      }
      for(const [itemId,group] of grouped){
        if(!(group.baseQty>0))continue;
        const found={invoiceId:String(inv.id||''),date,number,index,itemId,
          baseQty:group.baseQty,currency:currency(targets.get(itemId).currency),
          unitCost:group.amount/group.baseQty,
          allocatedDiscount:group.allocatedDiscount,
          allocatedAddition:group.allocatedAddition};
        const old=latest.get(itemId);
        // Latest date first. A matching date selects the highest invoice number
        // then append order. Edits of older invoices never supersede newer dated purchases.
        if(!old||date>old.date||(date===old.date&&(number>old.number||(number===old.number&&index>old.index))))latest.set(itemId,found);
      }
    });
    return latest;
  }
  function reconcile(items,invoices){
    const sources=recentPurchases(invoices,items);
    let updated=0;
    for(const item of (items||[])){
      if(!item || item.isBundle || !Array.isArray(item.units)||!item.units.length)continue;
      const source=sources.get(String(item.id));
      if(source){
        for(const unit of item.units){
          if(!Object.prototype.hasOwnProperty.call(unit,'manualCostBeforePurchase'))unit.manualCostBeforePurchase=nonnegative(unit.costPrice);
          const factor=finite(unit.factor)>0?finite(unit.factor):1;
          unit.costPrice=roundCost(source.unitCost/factor);
        }
        item.lastPurchaseCost={source:'purchase_invoice',invoiceId:source.invoiceId,date:source.date,
          currency:source.currency,baseUnitCost:roundCost(source.unitCost),quantityBase:source.baseQty,
          allocatedDiscount:source.allocatedDiscount,allocatedAddition:source.allocatedAddition};
        updated++;
      }else if(item.lastPurchaseCost?.source==='purchase_invoice'){
        // Last purchase was removed/changed: restore the old manually entered cost,
        // rather than leaving the item with a deleted invoice's stale price.
        for(const unit of item.units){
          if(Object.prototype.hasOwnProperty.call(unit,'manualCostBeforePurchase')){
            unit.costPrice=finite(unit.manualCostBeforePurchase);
            delete unit.manualCostBeforePurchase;
          }
        }
        delete item.lastPurchaseCost;
        updated++;
      }
    }
    return updated;
  }
  return {validInvoice,invoiceAllocations,recentPurchases,reconcile,convertPrecise,rowValue};
});
