/* Tiqany Acc Windows: local interface typography preference; never changes financial data. */
const UiFontScale = (() => {
  'use strict';
  const options = Object.freeze([
    { value: 'small', label: 'صغير' },
    { value: 'medium', label: 'متوسط' },
    { value: 'large', label: 'كبير — افتراضي' },
    { value: 'extra', label: 'كبير جداً' },
    { value: 'huge', label: 'ضخم' }
  ]);
  const pixels = Object.freeze({small:16,medium:17,large:18,extra:20,huge:22});
  const normalize = value => Object.hasOwn(pixels,value) ? value : 'large';
  function current() {return normalize(typeof State==='undefined'?undefined:State.settings?.uiFontSize);}
  function apply(value) {
    const key=normalize(value), px=pixels[key];
    document.documentElement.style.setProperty('font-size',px+'px');
    document.documentElement.style.setProperty('--ta-ui-font-ratio',(px/18).toFixed(3));
    document.documentElement.dataset.uiFontSize=key;
    return key;
  }
  function sync() {return apply(current());}
  async function set(value) {
    const chosen=apply(value);
    if(typeof State!=='undefined' && State.settings) {
      State.settings.uiFontSize=chosen;
      await (typeof SettingsDraftController!=='undefined' ? SettingsDraftController.stageSave() : StorageEngine.saveState());
    }
    if(typeof UI!=='undefined' && UI.toast)UI.toast('تمت معاينة حجم الخط؛ اضغط حفظ لاعتماده','info');
    return chosen;
  }
  return Object.freeze({options,current,apply,sync,set});
})();
