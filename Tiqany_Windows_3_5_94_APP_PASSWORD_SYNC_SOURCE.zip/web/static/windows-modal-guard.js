/* Windows 3.5.72 — explicit-action popups.
 * Backdrop clicks never dismiss; Escape uses the Cancel/Stay or red X action.
 * This module intentionally leaves all save/cancel handlers and accounting state unchanged.
 */
(function (root, create) {
    'use strict';
    const guard = create();
    if (typeof module === 'object' && module.exports) module.exports = guard;
    if (root) root.TiqanyDesktopPopupGuard = guard;
})(typeof window !== 'undefined' ? window : null, function () {
    'use strict';

    function labelOf(button) {
        return String(button.textContent || '').replace(/\s+/g, ' ').trim();
    }
    function isSaveAction(button) {
        const text = labelOf(button);
        return /(?:^|\s)(?:حفظ|احفظ)(?:\s|$)|\b(?:save|apply)\b/i.test(text);
    }
    function isCancelAction(button) {
        const text = labelOf(button);
        // Staying inside a confirmation is the equivalent of canceling it.
        return /(?:إلغاء|الغاء|البقاء|ابقَ|تراجع)|\b(?:cancel|stay)\b/i.test(text);
    }
    function isSmallCloseIcon(button) {
        const text = labelOf(button);
        if (isCancelAction(button) || isSaveAction(button)) return false;
        if (/^[×✕✖❌x]$/i.test(text)) return true;
        if (text.length !== 0) return false;
        const icon = button.querySelector?.('.fa-times, .fa-xmark, .fa-close, .fa-circle-xmark, [data-popup-dismiss]');
        if (icon) return true;
        const name = String(button.getAttribute?.('aria-label') || button.getAttribute?.('title') || '').trim();
        return /^(?:إغلاق|اغلاق|close|dismiss)$/i.test(name);
    }
    function inspect(buttons) {
        const items = Array.from(buttons || []);
        return {
            hasSave: items.some(isSaveAction),
            hasCancel: items.some(isCancelAction),
            closeIcons: items.filter(isSmallCloseIcon)
        };
    }
    function localeClose() {
        return typeof document !== 'undefined' && document.documentElement?.lang === 'en' ? 'Close' : 'إغلاق';
    }
    function decorate(box, dismiss) {
        if (!box) return;
        const buttons = Array.from(box.querySelectorAll('button'));
        const actions = inspect(buttons);
        // If a modal already has an explicit Cancel action, this is the only
        // non-saving exit. Do not allow an X icon to bypass it.
        if (actions.hasCancel) {
            actions.closeIcons.forEach(button => {
                button.classList.remove('ta-popup-exit-red');
                button.hidden = true;
                button.setAttribute('aria-hidden', 'true');
                button.tabIndex = -1;
            });
            box.querySelector('[data-ta-popup-exit="true"]')?.remove();
            return actions;
        }
        // Save-only and informational popups still require a way to cancel/close.
        const existing = actions.closeIcons[0];
        if (existing) {
            actions.closeIcons.slice(1).forEach(button => {
                button.hidden = true;
                button.setAttribute('aria-hidden', 'true');
                button.tabIndex = -1;
            });
            existing.hidden = false;
            existing.removeAttribute('aria-hidden');
            existing.removeAttribute('tabindex');
            existing.classList.add('ta-popup-exit-red', 'ta-popup-exit-floating');
            // Keep the existing close handler but anchor the X to the upper-right
            // of the popup, not the left edge of its RTL flex header.
            box.prepend(existing);
            existing.setAttribute('aria-label', localeClose());
            existing.setAttribute('title', localeClose());
            if (typeof existing.type !== 'undefined') existing.type = 'button';
            return actions;
        }
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'ta-popup-exit-red ta-popup-exit-floating';
        button.setAttribute('data-ta-popup-exit', 'true');
        button.setAttribute('aria-label', localeClose());
        button.setAttribute('title', localeClose());
        button.innerHTML = '<i class="fas fa-times" aria-hidden="true"></i>';
        button.addEventListener('click', event => {
            event.stopPropagation();
            dismiss();
        });
        box.appendChild(button);
        return actions;
    }
    return { decorate, inspect, isSaveAction, isCancelAction, isSmallCloseIcon };
});
