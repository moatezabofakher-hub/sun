/* Windows desktop adapter: uses the original FieldSync encrypted import and pairing code. */
(function () {
  'use strict';
  const syncHeaderHeight=()=>{const h=document.querySelector('.ta-app-header');if(h)document.documentElement.style.setProperty('--ta-header-height',h.offsetHeight+'px');};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{
    syncHeaderHeight();if(window.ResizeObserver){new ResizeObserver(syncHeaderHeight).observe(document.querySelector('.ta-app-header'));}
  },{once:true});else syncHeaderHeight();
  if (!window.WindowsDesktop) return;
  // The native title-bar X, Alt+F4 and File > Close must show the same
  // confirmation as the header Exit button (never call the exit IPC here).
  if (typeof window.WindowsDesktop.onExitRequested === 'function') {
    window.WindowsDesktop.onExitRequested(() => {
      try { if (typeof UI !== 'undefined') UI.requestExitFromHeader(); }
      catch (error) { console.warn('Exit confirmation could not open:', error); }
    });
  }
  window.WindowsDesktop.onLanRequest(({requestId, raw, pairing}) => {
    try {
      if (!window.AndroidLocalSync) return;
      if (typeof FieldSync === 'undefined') {
        window.AndroidLocalSync.reply(requestId, JSON.stringify({error: 'التطبيق لم يكتمل تحميله'}));
        return;
      }
      if (pairing) {
        if (typeof FieldSync.receivePairingPacket === 'function') FieldSync.receivePairingPacket(requestId,raw);
        else window.AndroidLocalSync.reply(requestId, JSON.stringify({error: 'ربط الأجهزة غير متاح'}));
      } else {
        FieldSync.receiveLanPacket(requestId,raw);
      }
    } catch (e) {
      window.AndroidLocalSync.reply(requestId,JSON.stringify({error:'تعذر استقبال الطلب'}));
    }
  });
  window.WindowsDesktop.onLanStatus(status => {
    try {if(typeof FieldSync!=='undefined') FieldSync.onLanStatus(String(status));}catch(e){console.warn(e);}
  });
  window.WindowsDesktop.onPrinterStatus(event => {
    try { window.__nativePrinterEvent?.(event); } catch (e) {console.warn(e);}
  });
  window.WindowsDesktop.onBackupStatus(status => {
    try {
      window.__nativeBackupStatus?.(JSON.stringify(status));
      if(typeof BackupController!=='undefined') BackupController.refresh();
    } catch(e){console.warn(e);}
  });
  window.WindowsDesktop.onBarcodeResult(({target,code,message}) => {
    if (String(code||'').trim()) window.BarcodeFeedback?.read(target==='item'||window.BarcodeFeedback?.isKnown(code));
    window.__nativeBarcodeResult?.(target,code,message);
  });
})();
