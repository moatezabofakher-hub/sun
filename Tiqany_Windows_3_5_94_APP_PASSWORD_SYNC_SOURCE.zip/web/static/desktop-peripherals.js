/* Tiqany Acc Windows — USB devices dashboard.
 * Native printers are discovered through the Windows print spooler.
 * Most USB/Bluetooth HID barcode readers act as keyboard wedges; no exclusive driver is required.
 */
(() => {
  'use strict';
  if (!window.WindowsDesktop || !window.WindowsDevices) return;
  const devices = window.WindowsDevices;
  let config = null;
  let panel, scannerField;
  let scanBuffer = '', scanStart = 0, scanLast = 0, scanEditSnapshot = null;
  const el = id => document.getElementById(id);
  const show = (msg, type='info') => {
    if (typeof UI !== 'undefined' && typeof UI.toast === 'function') UI.toast(msg,type);
    else console.info(msg);
    if (el('taDeviceMessage')) el('taDeviceMessage').textContent = msg;
  };
  const esc = text => String(text ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const panelHTML = `
  <div id="taDeviceOverlay" class="ta-device-overlay" role="presentation">
    <section id="taDevicesPanel" class="ta-device-panel" role="dialog" aria-modal="true" aria-labelledby="taDeviceTitle" dir="rtl">
      <header class="ta-device-heading"><div><strong id="taDeviceTitle"><i class="fas fa-plug"></i> الأجهزة والطباعة</strong><small>طابعات USB • قارئ باركود • أدوات نقطة البيع</small></div>
        <button type="button" class="ta-device-close" id="taDeviceClose" aria-label="إغلاق">×</button></header>
      <div class="ta-device-scroll">
        <div class="ta-device-card">
          <h3><i class="fas fa-print"></i> طابعات ويندوز المثبتة</h3>
          <p>يتعرّف التطبيق على طابعات USB والشبكة المعرفة في Windows. لطابعة الإيصالات اختر ESC/POS، ولطابعات A4 اختر طباعة عادية.</p>
          <label for="taPrinterSelect">اسم الطابعة</label>
          <div class="ta-device-row"><select id="taPrinterSelect" aria-label="الطابعة"><option value="">جارٍ الكشف...</option></select>
            <button id="taPrinterRefresh" type="button" class="ta-device-secondary">تحديث</button></div>
          <div class="ta-device-row ta-device-radio"><label><input type="radio" name="taPrinterMode" value="thermal"> إيصالات ESC/POS</label>
            <label><input type="radio" name="taPrinterMode" value="system"> طباعة ويندوز A4</label></div>
          <div id="taThermalPaper" class="ta-device-row ta-device-papers"><span>عرض الإيصال:</span>
            <label><input type="radio" name="taPaper" value="80"> 80 مم</label><label><input type="radio" name="taPaper" value="58"> 58 مم</label></div>
          <div class="ta-device-row"><button id="taDeviceSave" class="ta-device-primary" type="button">حفظ الإعدادات</button>
            <button id="taDeviceTestPrint" class="ta-device-secondary" type="button">طباعة تجريبية</button>
            <button id="taDevicePagePrint" class="ta-device-secondary" type="button">طباعة الصفحة</button></div>
        </div>
        <div class="ta-device-card">
          <h3><i class="fas fa-barcode"></i> قارئ باركود USB</h3>
          <p>يدعم قارئات USB-HID وBluetooth-HID التي تعمل كلوحة مفاتيح. عند فتح فاتورة أو نقطة بيع امسح مباشرة دون ضغط زر؛ كل قراءة تضيف قطعة. إذا فعّلت الخيار في ضبط الفواتير، فإن مسح مادة من الشاشة الرئيسية يفتح نقطة بيع جديدة. لا تُحفظ الفاتورة تلقائياً.</p>
          <label class="ta-device-check"><input id="taScannerAuto" type="checkbox"> التقاط قارئ الباركود تلقائياً في الفواتير ونقطة البيع حتى أثناء البحث في الحقول</label>
          <div class="ta-device-row"><label>أقل عدد أحرف<input type="number" id="taScannerMin" min="3" max="32" value="4"></label>
            <label>المدة القصوى بين الأحرف (مللي ثانية)<input type="number" id="taScannerGap" min="30" max="500" step="10" value="110"></label></div>
          <label for="taScannerSuffix">زر نهاية القراءة</label><select id="taScannerSuffix"><option value="both">Enter أو Tab</option><option value="enter">Enter</option><option value="tab">Tab</option></select>
          <label for="taScanInput">حقل تجربة ومسح متتابع (يمكن إبقاؤه مفتوحاً)</label>
          <div class="ta-device-row"><input id="taScanInput" type="text" dir="ltr" inputmode="none" placeholder="ضع المؤشر هنا وامسح الباركود" autocomplete="off" spellcheck="false">
            <button id="taScanSubmit" class="ta-device-primary" type="button">إضافة / اختبار</button></div>
          <div class="ta-device-row"><button id="taScanFocus" class="ta-device-secondary" type="button">تركيز الماسح</button>
            <label>الوجهة <select id="taScannerTarget"><option value="auto">تلقائي</option><option value="invoice">فاتورة مفتوحة</option><option value="item">بطاقة المادة</option><option value="test">تجربة فقط</option></select></label></div>
          <p id="taScannerResult" class="ta-device-result" aria-live="polite">جرّب مسح باركود للتأكد من وصول الأرقام.</p>
        </div>
        <div class="ta-device-card ta-device-tip"><h3><i class="fas fa-circle-info"></i> إرشادات تشغيل عملية</h3>
          <p>إذا لم تظهر الطابعة، ثبّت تعريفها أولاً من إعدادات Windows. نجاح إرسال أمر الطباعة لا يؤكد خروج الورقة؛ افحص الكابل والورق والطابور. قارئات COM/Serial تحتاج تهيئة الجهاز لوضع HID Keyboard. من لوحة المفاتيح: <b>Ctrl+Shift+P</b> للأجهزة، و<b>Ctrl+Shift+B</b> لمسح الباركود، و<b>Ctrl+P</b> للطباعة.</p></div>
      </div><footer class="ta-device-footer"><span id="taDeviceMessage" role="status" aria-live="polite">إعدادات الأجهزة منفصلة عن البيانات المحاسبية.</span></footer>
    </section>
  </div>`;
  function syncPaper() { const paper=el('taThermalPaper'); if(paper) paper.hidden=document.querySelector('input[name="taPrinterMode"]:checked')?.value !== 'thermal'; }
  function populateFields() {
    if (!config || !panel) return;
    const printer=el('taPrinterSelect'); if (printer && [...printer.options].some(o=>o.value===config.printerName)) printer.value=config.printerName;
    document.querySelectorAll('input[name="taPrinterMode"]').forEach(x=>x.checked=x.value===config.printMode);
    document.querySelectorAll('input[name="taPaper"]').forEach(x=>x.checked=Number(x.value)===config.paperMm);
    el('taScannerAuto').checked=config.scanner.autoCapture;
    el('taScannerMin').value=config.scanner.minLength;
    el('taScannerGap').value=config.scanner.maxGapMs;
    el('taScannerSuffix').value=config.scanner.suffix;
    syncPaper();
  }
  async function refreshPrinters() {
    const select=el('taPrinterSelect'); if(!select) return;
    select.disabled=true; select.replaceChildren(new Option('جارٍ تحديث طابعات Windows...', ''));
    try {
      const printers=await devices.printers();
      select.replaceChildren(new Option('— اختر الطابعة —', ''));
      for (const p of printers) select.add(new Option((p.displayName||p.name)+(p.isDefault?' (الافتراضية)':''),p.name));
      if (config?.printerName && printers.some(p=>p.name===config.printerName)) select.value=config.printerName;
      if (!printers.length) show('لم تُكتشف طابعات. ثبّت تعريف USB أو شغّل خدمة Windows Print Spooler.','warn');
      else show('تم الكشف عن '+printers.length+' طابعة مثبتة.','success');
    } catch (e) {select.replaceChildren(new Option('تعذر قراءة طابعات Windows', ''));show(e.message,'error');}
    finally {select.disabled=false;}
  }
  function gather() {
    return {
      printerName:el('taPrinterSelect').value,
      printMode:document.querySelector('input[name="taPrinterMode"]:checked')?.value||'thermal',
      paperMm:Number(document.querySelector('input[name="taPaper"]:checked')?.value||80),
      scanner:{autoCapture:el('taScannerAuto').checked,minLength:Number(el('taScannerMin').value),
        maxGapMs:Number(el('taScannerGap').value),suffix:el('taScannerSuffix').value}
    };
  }
  async function save() {
    try {
      config=await devices.saveSettings(gather()); populateFields();
      // Keep the original thermal raster layout aligned to the selected paper width.
      if(typeof State!=='undefined' && State.settings && config.printMode==='thermal') {
        State.settings.printerWidth=config.paperMm;
      }
      show('تم حفظ إعدادات الأجهزة.','success'); return true;
    }catch(e){show('تعذر الحفظ: '+e.message,'error');return false;}
  }
  function isInvoice() {
    try {return typeof AppNav!=='undefined' && ['invoice_form','pos'].includes(AppNav.current()?.screen) && typeof InvoiceController!=='undefined' && !!InvoiceController.draft;}
    catch(_){return false;}
  }
  function isItemEditor() {return !!el('itmBarcode') && !!el('itmBarcode').isConnected;}
  function routeBarcode(code, fromInput=false) {
    const normalized=String(code||'').trim();
    if(!normalized || normalized.length>128 || /[\u0000-\u001f]/.test(normalized))return false;
    window.BarcodeFeedback?.read(window.BarcodeFeedback?.isKnown(normalized) || isItemEditor()); // audible at completed HID decode
    const target=(panel?.style.display==='flex') ? (el('taScannerTarget')?.value||'auto') : 'auto';
    const result=el('taScannerResult');
    const say=message=>{if(result)result.textContent=message;show(message, 'info');};
    if(target==='test') {say('تمت قراءة الباركود: '+normalized);return true;}
    if ((target==='item' || (target==='auto' && isItemEditor())) && isItemEditor()) {
      const field=el('itmBarcode');field.value=normalized;field.dispatchEvent(new Event('input',{bubbles:true}));
      say('تم إدراج الباركود في بطاقة المادة: '+normalized+' — احفظ المادة.');return true;
    }
    if ((target==='invoice'||target==='auto') && isInvoice()) {
      const found=typeof State!=='undefined' && State.items?.some(item=>String(item.barcode||'').trim().toLowerCase()===normalized.toLowerCase());
      if(AppNav.current()?.screen==='pos') POSController.addBarcode(normalized); else InvoiceController.addItemByBarcode(normalized);
      if(result)result.textContent=found?'تمت إضافة صنف بالباركود: '+normalized:'الباركود غير موجود: '+normalized;
      return !!found;
    }
    if (target==='auto' && isHomeScannerEnabled()) return POSController.openFromBarcode(normalized);
    say('تمت القراءة: '+normalized+'؛ افتح فاتورة لإضافة المادة أو اختر تجربة فقط.');return true;
  }
  function scanFromField() {
    const input=el('taScanInput'); if(!input) return;
    const code=input.value.trim();if(!code){input.focus();return;}
    routeBarcode(code,true);input.value='';input.focus();
  }
  async function open(focusScanner=false) {
    if(!panel) {
      const host=document.createElement('div'); host.id='taDesktopHardwareRoot';host.innerHTML=panelHTML;
      document.body.appendChild(host);panel=el('taDeviceOverlay');scannerField=el('taScanInput');
      el('taDeviceClose').addEventListener('click',close);
      // Clicking outside the device panel intentionally does nothing.
      // Users leave with the clearly visible red X.
      el('taPrinterRefresh').addEventListener('click',refreshPrinters);
      el('taDeviceSave').addEventListener('click',save);
      el('taDeviceTestPrint').addEventListener('click',async()=>{
        if(!(await save()))return;
        try {const result=await devices.testPrinter();show(result.message||'تم إرسال أمر اختبار الطابعة','success');}
        catch(e){show('فشل اختبار الطابعة: '+e.message,'error');}
      });
      el('taDevicePagePrint').addEventListener('click',async()=>{
        if(!(await save()))return;
        close();try{await devices.printPage(false);}catch(e){show(e.message,'error');}
      });
      document.querySelectorAll('input[name="taPrinterMode"]').forEach(x=>x.addEventListener('change',syncPaper));
      el('taScanFocus').addEventListener('click',()=>scannerField.focus());
      el('taScanSubmit').addEventListener('click',scanFromField);
      scannerField.addEventListener('keydown',e=>{
        if (e.key==='Enter'||e.key==='Tab') {e.preventDefault();scanFromField();}
      });
    }
    panel.style.display='flex';
    try {config=await devices.settings();populateFields();await refreshPrinters();}
    catch(e){show('تعذر تحميل إعدادات الأجهزة: '+e.message,'error');}
    if(focusScanner) {el('taScannerTarget').value='auto';scannerField.focus();}
    else el('taDeviceClose').focus();
  }
  function close() {if(panel) panel.style.display='none';}
  function openScanner() {return open(true);}
  // Listen on the whole invoice/POS, without requiring a barcode button or dedicated focus.
  // HID readers emulate keyboards. We classify the complete rapid sequence at Enter/Tab
  // and restore the prior value of a focused editable field before routing the scan.
  function isHomeScannerEnabled() {
    try {return State.settings?.posScanFromHome===true && AppNav.current()?.screen==='dashboard';}
    catch(_){return false;}
  }
  function canAutoScan() {
    if(panel?.style.display==='flex')return false; // device test field handles its own scans
    if(!config?.scanner.autoCapture)return false;
    if(!isInvoice()&&!isHomeScannerEnabled()&&!isItemEditor())return false;
    const modal=el('modalContainer'),dialog=el('dialogContainer');
    if(modal&&!modal.classList.contains('hidden'))return false;
    if(dialog&&!dialog.classList.contains('hidden'))return false;
    return true;
  }
  function editableSnapshot(target) {
    if(!target || !target.matches?.('input:not([type="password"]):not([type="file"]),textarea'))return null;
    if(target.disabled||target.readOnly||target.id==='itmBarcode')return null;
    const type=String(target.type||'text').toLowerCase();
    if(!['text','search','number','tel','url','email'].includes(type))return null;
    let start=null,end=null;
    try {start=target.selectionStart;end=target.selectionEnd;} catch(_){}
    return {element:target,value:target.value,start,end};
  }
  function restoreEditor(snapshot) {
    if(!snapshot?.element?.isConnected)return;
    const input=snapshot.element;
    if(input.value!==snapshot.value){
      input.value=snapshot.value;
      input.dispatchEvent(new Event('input',{bubbles:true}));
    }
    if(snapshot.start!==null && snapshot.end!==null) {
      try{input.setSelectionRange(snapshot.start,snapshot.end);}catch(_){}
    }
  }
  function resetScan() {scanBuffer='';scanStart=0;scanLast=0;scanEditSnapshot=null;}
  function isKnownBarcode(code) {
    return typeof State!=='undefined' && State.items?.some(item=>String(item.barcode||'').trim().toLowerCase()===code.toLowerCase());
  }
  function onKeyboardScan(e) {
    if(!canAutoScan()){resetScan();return;}
    if(e.ctrlKey||e.metaKey||e.altKey||e.isComposing||e.repeat){resetScan();return;}
    const target=e.target;
    if(target?.isContentEditable || target?.closest?.('[contenteditable="true"],[role="textbox"]')){resetScan();return;}
    if(target?.matches?.('select,input[type="password"],input[type="file"],textarea')){resetScan();return;}
    // Enter/Tab acts as a suffix. No action is triggered by typing a barcode's
    // characters alone: this avoids creating invoices from partial reads.
    const now=performance.now();
    if(e.key==='Enter'||e.key==='Tab'){
      const code=scanBuffer;
      const allowed=config.scanner.suffix==='both'||config.scanner.suffix===e.key.toLowerCase();
      const rapid=code.length>=config.scanner.minLength &&
        (code.length<2||(now-scanStart)/(code.length-1)<=config.scanner.maxGapMs) &&
        (now-scanLast)<=Math.max(400,config.scanner.maxGapMs*4);
      const known=rapid && isKnownBarcode(code);
      // Unknown barcode warnings only if the input resembles a scanner burst,
      // not when a user types text manually into a form.
      const likelyUnknown=rapid && !known && /^[0-9A-Za-z_.-]{6,128}$/.test(code) &&
        (code.length<2||(scanLast-scanStart)/(code.length-1)<Math.min(65,config.scanner.maxGapMs));
      const snapshot=scanEditSnapshot;
      resetScan();
      if(allowed && (known||likelyUnknown)){
        e.preventDefault();e.stopPropagation();
        restoreEditor(snapshot);
        routeBarcode(code);
      }
      return;
    }
    if(e.key.length!==1 || /\s/.test(e.key)){resetScan();return;}
    if(now-scanLast>config.scanner.maxGapMs*2 || !scanBuffer){
      resetScan();scanStart=now;scanEditSnapshot=editableSnapshot(target);
    }
    if(scanEditSnapshot?.element && scanEditSnapshot.element!==target){
      resetScan();scanStart=now;scanEditSnapshot=editableSnapshot(target);
    }
    scanBuffer+=e.key;scanLast=now;
    if(scanBuffer.length>128)resetScan();
  }
  function init() {
    const actionGroup=el('headerActionGroup');
    if(actionGroup && !el('taDeviceTopButton')){
      const btn=document.createElement('button');btn.id='taDeviceTopButton';btn.type='button';
      btn.title='طابعات USB وقارئ الباركود';btn.className='ta-device-top-button';
      btn.innerHTML='<i class="fas fa-plug"></i><span>الأجهزة</span>';
      btn.addEventListener('click',()=>open()); actionGroup.insertBefore(btn,actionGroup.firstChild);
    }
    document.addEventListener('keydown',onKeyboardScan,true);
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&panel?.style.display==='flex')close();});
    window.WindowsDesktop.onDevicesOpen(()=>open());
    window.WindowsDesktop.onScannerOpen(openScanner);
    window.WindowsDesktop.onDeviceConfig(newConfig=>{config=newConfig;populateFields();});
    window.WindowsDesktop.onPrinterStatus(status=>{if(panel?.style.display==='flex')show(status.message||status.state,status.state==='error'?'error':'info');});
    devices.settings().then(x=>{config=x;}).catch(()=>{config={scanner:{autoCapture:true,minLength:4,maxGapMs:110,suffix:'both'}};});
  }
  window.DesktopDevices=Object.freeze({open,openScanner,close,routeBarcode});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);
  else init();
})();
